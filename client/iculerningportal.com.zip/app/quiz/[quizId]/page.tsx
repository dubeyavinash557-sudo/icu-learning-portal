import { auth } from "@/auth";
import prisma from "@/lib/prisma";
import { redirect, notFound } from "next/navigation";
import QuizClient from "./QuizClient";

interface PageProps {
  params: Promise<{
    quizId: string;
  }>;
}

export default async function QuizPage({
  params,
}: PageProps) {
  // --------------------------------------------------
  // 1. Authentication
  // --------------------------------------------------
  const session = await auth();

  if (!session?.user?.email) {
    redirect("/login");
  }

  // --------------------------------------------------
  // 2. Verify user
  // --------------------------------------------------
  const user = await prisma.user.findUnique({
    where: {
      email: session.user.email,
    },
    select: {
      id: true,
    },
  });

  if (!user) {
    redirect("/login");
  }

  // --------------------------------------------------
  // 3. Get quiz ID
  // --------------------------------------------------
  const { quizId } = await params;

  if (
    typeof quizId !== "string" ||
    quizId.trim().length === 0
  ) {
    notFound();
  }

  // --------------------------------------------------
  // 4. Get quiz
  // --------------------------------------------------
  const quiz = await prisma.quiz.findUnique({
    where: {
      id: quizId,
    },
    include: {
      course: {
        select: {
          id: true,
          title: true,
        },
      },
      questions: {
        orderBy: {
          id: "asc",
        },
      },
    },
  });

  // --------------------------------------------------
  // 5. Quiz not found
  // --------------------------------------------------
  if (!quiz) {
    notFound();
  }

  // --------------------------------------------------
  // 6. Empty quiz protection
  // --------------------------------------------------
  if (quiz.questions.length === 0) {
    notFound();
  }

  return (
    <QuizClient
      quiz={quiz}
    />
  );
}