import "server-only";

import Razorpay from "razorpay";

// ============================================================
// RAZORPAY SERVER CLIENT
// ============================================================
//
// SECURITY RULES
// ------------------------------------------------------------
// 1. This module is SERVER-ONLY.
// 2. Never import this file into a Client Component.
// 3. RAZORPAY_KEY_SECRET must NEVER reach the browser.
// 4. Razorpay credentials must come only from environment
//    variables.
// 5. The browser receives only RAZORPAY_KEY_ID through the
//    create-order API when Razorpay Checkout is opened.
//
// IMPORTANT
// ------------------------------------------------------------
// Do NOT put the real Razorpay keys directly in this file.
//
// Correct:
//
// RAZORPAY_KEY_ID=rzp_live_XXXXXXXX
// RAZORPAY_KEY_SECRET=XXXXXXXX
//
// inside Vercel Environment Variables.
//
// ============================================================

// ============================================================
// READ SERVER ENVIRONMENT VARIABLES
// ============================================================

const razorpayKeyId = process.env.RAZORPAY_KEY_ID?.trim();

const razorpayKeySecret =
  process.env.RAZORPAY_KEY_SECRET?.trim();

// ============================================================
// ENVIRONMENT VALIDATION
// ============================================================
//
// Fail immediately if the server is incorrectly configured.
//
// This prevents the application from attempting to create
// Razorpay orders without valid server credentials.
//
// ============================================================

if (!razorpayKeyId) {
  throw new Error(
    "RAZORPAY_KEY_ID is missing from environment variables."
  );
}

if (!razorpayKeySecret) {
  throw new Error(
    "RAZORPAY_KEY_SECRET is missing from environment variables."
  );
}

// ============================================================
// BASIC KEY VALIDATION
// ============================================================
//
// Razorpay Key ID is public and normally begins with:
//
// rzp_test_
// or
// rzp_live_
//
// We do not hard-code either environment here.
//
// The actual environment is controlled by the key stored in
// Vercel Environment Variables.
//
// ============================================================

if (
  !razorpayKeyId.startsWith("rzp_test_") &&
  !razorpayKeyId.startsWith("rzp_live_")
) {
  throw new Error(
    "Invalid RAZORPAY_KEY_ID format."
  );
}

// ============================================================
// GLOBAL RAZORPAY CLIENT
// ============================================================
//
// Next.js server modules can be evaluated multiple times,
// especially during development or server reloads.
//
// Keeping one Razorpay instance on globalThis prevents
// unnecessary client recreation.
//
// The secret remains server-side because this entire module
// is protected by:
//
// import "server-only";
//
// ============================================================

const globalForRazorpay =
  globalThis as typeof globalThis & {
    razorpay?: Razorpay;
  };

// ============================================================
// CREATE / REUSE RAZORPAY CLIENT
// ============================================================

const razorpay =
  globalForRazorpay.razorpay ??
  new Razorpay({
    key_id: razorpayKeyId,
    key_secret: razorpayKeySecret,
  });

// ============================================================
// STORE CLIENT INSTANCE
// ============================================================
//
// We can safely reuse the instance on the server.
//
// No Razorpay secret is exported to the browser.
//
// ============================================================

globalForRazorpay.razorpay = razorpay;

// ============================================================
// EXPORT
// ============================================================
//
// Server-side files such as:
//
// /api/payments/create-order
// /api/payments/verify
// /api/payments/webhook
//
// can import this client.
//
// ============================================================

export default razorpay;