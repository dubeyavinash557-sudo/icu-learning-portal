"use client";

import Link from "next/link";
import { useEffect, useState } from "react";

import {
  ArrowRight,
  Star,
  Clock3,
  BadgeCheck,
  Crown,
  BookOpen,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Award,
} from "lucide-react";

type Lesson = {
  id: string;
  title: string;
  lessonOrder: number;
  duration: number;
};

type NextLesson = {
  id: string;
  title: string;
  lessonOrder: number;
};

type Certificate = {
  id: string;
  certificateNo: string;
  issuedAt: string;
};

type Course = {
  id: string;
  progress: number;
  completed: boolean;
  totalLessons: number;
  completedLessons: number;
  remainingLessons: number;
  enrolledAt: string;

  nextLesson: NextLesson | null;

  certificate: Certificate | null;

  course: {
    id: string;
    title: string;
    slug: string;
    image: string;
    description: string;
    instructor: string;
    rating: number;
    duration: number;
    language: string;
    level: string;
    price: number;
    isPremium: boolean;
    lessons: Lesson[];
  };
};

const colors = [
  "from-blue-500 to-cyan-500",
  "from-emerald-500 to-green-500",
  "from-purple-500 to-pink-500",
  "from-orange-500 to-amber-500",
  "from-rose-500 to-red-500",
];

export default function MyCourses() {
  const [courses, setCourses] =
    useState<Course[]>([]);

  const [loading, setLoading] =
    useState(true);

  const [error, setError] =
    useState("");

  // ==========================================================
  // LOAD COURSES
  // ==========================================================

  useEffect(() => {
    let mounted = true;

    async function loadCourses() {
      try {
        setLoading(true);
        setError("");

        const response =
          await fetch(
            "/api/my-courses",
            {
              method: "GET",
              cache: "no-store",
            }
          );

        const data =
          await response.json();

        if (!response.ok) {
          throw new Error(
            data?.message ||
              "Failed to load courses."
          );
        }

        if (!mounted) {
          return;
        }

        setCourses(
          Array.isArray(data?.courses)
            ? data.courses
            : []
        );
      } catch (error) {
        console.error(
          "MY COURSES LOAD ERROR:",
          error
        );

        if (!mounted) {
          return;
        }

        setError(
          error instanceof Error
            ? error.message
            : "Unable to load your courses."
        );
      } finally {
        if (mounted) {
          setLoading(false);
        }
      }
    }

    loadCourses();

    return () => {
      mounted = false;
    };
  }, []);

  // ==========================================================
  // LOADING
  // ==========================================================

  if (loading) {
    return (
      <section className="rounded-3xl border border-slate-200 bg-white p-8 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-blue-50 text-blue-600">
            <Loader2
              size={24}
              className="animate-spin"
            />
          </div>

          <div>
            <h2 className="text-2xl font-black text-slate-900">
              My Courses
            </h2>

            <p className="mt-1 text-sm text-slate-500">
              Loading your learning programs...
            </p>
          </div>
        </div>

        <div className="mt-8 space-y-4">
          {[1, 2].map((item) => (
            <div
              key={item}
              className="animate-pulse rounded-3xl border border-slate-200 p-5"
            >
              <div className="flex flex-col gap-5 lg:flex-row">
                <div className="h-48 w-full rounded-2xl bg-slate-200 lg:w-72" />

                <div className="flex-1 space-y-4">
                  <div className="h-5 w-32 rounded bg-slate-200" />
                  <div className="h-8 w-3/4 rounded bg-slate-200" />
                  <div className="h-4 w-1/2 rounded bg-slate-200" />
                  <div className="h-3 w-full rounded bg-slate-200" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    );
  }

  // ==========================================================
  // ERROR
  // ==========================================================

  if (error) {
    return (
      <section className="rounded-3xl border border-red-200 bg-white p-8 shadow-xl">
        <div className="flex items-start gap-4 rounded-2xl border border-red-200 bg-red-50 p-5">
          <AlertCircle
            size={24}
            className="mt-0.5 shrink-0 text-red-600"
          />

          <div>
            <h2 className="font-black text-red-800">
              Unable to load My Courses
            </h2>

            <p className="mt-1 text-sm leading-6 text-red-700">
              {error}
            </p>
          </div>
        </div>
      </section>
    );
  }

  // ==========================================================
  // EMPTY
  // ==========================================================

  if (courses.length === 0) {
    return (
      <section className="rounded-3xl border border-slate-200 bg-white p-8 shadow-xl">
        <div className="mx-auto max-w-xl py-8 text-center">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-blue-50 text-blue-600">
            <BookOpen size={30} />
          </div>

          <h2 className="mt-5 text-3xl font-black text-slate-900">
            My Courses
          </h2>

          <p className="mt-3 leading-7 text-slate-500">
            You are not enrolled in any course yet.
            Start learning by exploring our ICU
            courses.
          </p>

          <Link
            href="/courses"
            className="mt-6 inline-flex items-center gap-2 rounded-xl bg-blue-600 px-6 py-3 font-bold text-white shadow-lg shadow-blue-600/20 transition hover:bg-blue-700"
          >
            Explore Courses
            <ArrowRight size={18} />
          </Link>
        </div>
      </section>
    );
  }

  // ==========================================================
  // MAIN
  // ==========================================================

  return (
    <section className="rounded-3xl border border-slate-200 bg-white p-5 shadow-xl sm:p-8">
      {/* Header */}

      <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-blue-50 text-blue-600">
              <BookOpen size={22} />
            </div>

            <h2 className="text-3xl font-black tracking-tight text-slate-900">
              My Courses
            </h2>
          </div>

          <p className="mt-3 text-slate-500">
            Continue your enrolled ICU learning
            programs with real-time progress.
          </p>
        </div>

        <Link
          href="/courses"
          className="inline-flex items-center justify-center gap-2 rounded-xl border border-slate-200 px-5 py-3 text-sm font-bold text-slate-700 transition hover:border-blue-300 hover:bg-blue-50 hover:text-blue-700"
        >
          View All Courses
          <ArrowRight size={17} />
        </Link>
      </div>

      {/* Course List */}

      <div className="space-y-6">
        {courses.map(
          (item, index) => {
            const progress = Math.min(
              Math.max(item.progress, 0),
              100
            );

            const gradient =
              colors[
                index % colors.length
              ];

            return (
              <article
                key={item.id}
                className="group overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm transition-all duration-300 hover:-translate-y-1 hover:border-blue-200 hover:shadow-xl"
              >
                <div className="flex flex-col lg:flex-row">
                  {/* Course Image */}

                  <div className="relative shrink-0 lg:w-72">
                    <img
                      src={item.course.image}
                      alt={item.course.title}
                      className="h-56 w-full object-cover lg:h-full lg:min-h-[300px]"
                    />

                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 via-transparent to-transparent" />

                    <div className="absolute bottom-4 left-4 right-4">
                      <div className="flex flex-wrap gap-2">
                        {item.course.isPremium && (
                          <span className="inline-flex items-center gap-1.5 rounded-full bg-yellow-400 px-3 py-1.5 text-xs font-black text-yellow-950 shadow-lg">
                            <Crown size={14} />
                            Premium
                          </span>
                        )}

                        {item.completed && (
                          <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-500 px-3 py-1.5 text-xs font-black text-white shadow-lg">
                            <CheckCircle2
                              size={14}
                            />
                            Completed
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Course Content */}

                  <div className="flex flex-1 flex-col justify-between p-5 sm:p-7">
                    <div>
                      {/* Meta */}

                      <div className="mb-4 flex flex-wrap items-center gap-4">
                        <span className="inline-flex items-center gap-1.5 rounded-full bg-amber-50 px-3 py-1.5 text-sm font-bold text-amber-700">
                          <Star
                            size={15}
                            fill="currentColor"
                          />
                          {item.course.rating.toFixed(
                            1
                          )}
                        </span>

                        <span className="text-sm text-slate-500">
                          {item.course.level}
                        </span>

                        <span className="text-sm text-slate-500">
                          {item.course.language}
                        </span>
                      </div>

                      {/* Title */}

                      <h3 className="text-2xl font-black leading-tight text-slate-900 sm:text-3xl">
                        {item.course.title}
                      </h3>

                      <p className="mt-3 line-clamp-2 text-sm leading-6 text-slate-500">
                        {item.course.description}
                      </p>

                      {/* Course Stats */}

                      <div className="mt-5 flex flex-wrap gap-4 text-sm text-slate-500">
                        <div className="inline-flex items-center gap-2">
                          <BookOpen
                            size={16}
                            className="text-blue-600"
                          />

                          <span>
                            {item.completedLessons} /{" "}
                            {item.totalLessons} lessons
                          </span>
                        </div>

                        <div className="inline-flex items-center gap-2">
                          <Clock3
                            size={16}
                            className="text-cyan-600"
                          />

                          <span>
                            {item.remainingLessons}{" "}
                            remaining
                          </span>
                        </div>

                        <div className="inline-flex items-center gap-2">
                          <BadgeCheck
                            size={16}
                            className={
                              item.certificate
                                ? "text-emerald-600"
                                : "text-slate-400"
                            }
                          />

                          <span>
                            {item.certificate
                              ? "Certificate Earned"
                              : "Certificate Locked"}
                          </span>
                        </div>
                      </div>

                      {/* Progress */}

                      <div className="mt-7">
                        <div className="mb-2 flex items-center justify-between gap-4">
                          <span className="text-sm font-bold text-slate-700">
                            Course Progress
                          </span>

                          <span className="text-sm font-black text-blue-700">
                            {progress}%
                          </span>
                        </div>

                        <div className="h-3 overflow-hidden rounded-full bg-slate-200">
                          <div
                            className={`h-full rounded-full bg-gradient-to-r ${gradient} transition-all duration-700`}
                            style={{
                              width: `${progress}%`,
                            }}
                          />
                        </div>

                        <div className="mt-2 flex justify-between text-xs text-slate-400">
                          <span>
                            {item.completedLessons}{" "}
                            completed
                          </span>

                          <span>
                            {item.remainingLessons}{" "}
                            remaining
                          </span>
                        </div>
                      </div>

                      {/* Next Lesson */}

                      {!item.completed &&
                        item.nextLesson && (
                          <div className="mt-6 rounded-2xl border border-blue-100 bg-blue-50 p-4">
                            <p className="text-xs font-black uppercase tracking-[0.15em] text-blue-600">
                              Continue From
                            </p>

                            <div className="mt-2 flex items-start gap-3">
                              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-blue-600 text-white">
                                <PlayIcon />
                              </div>

                              <div className="min-w-0">
                                <p className="text-sm font-bold text-slate-900">
                                  Lesson{" "}
                                  {
                                    item
                                      .nextLesson
                                      .lessonOrder
                                  }
                                </p>

                                <p className="mt-0.5 truncate text-sm text-slate-600">
                                  {
                                    item
                                      .nextLesson
                                      .title
                                  }
                                </p>
                              </div>
                            </div>
                          </div>
                        )}
                    </div>

                    {/* Actions */}

                    <div className="mt-7 flex flex-col gap-3 sm:flex-row">
                      {!item.completed &&
                      item.nextLesson ? (
                        <Link
                          href={`/courses/${item.course.id}/lesson/${item.nextLesson.id}`}
                          className="inline-flex items-center justify-center gap-2 rounded-xl bg-blue-600 px-6 py-3.5 text-sm font-black text-white shadow-lg shadow-blue-600/20 transition hover:bg-blue-700"
                        >
                          Continue Learning
                          <ArrowRight
                            size={18}
                          />
                        </Link>
                      ) : item.completed ? (
                        <Link
                          href="/dashboard/certificates"
                          className="inline-flex items-center justify-center gap-2 rounded-xl bg-emerald-600 px-6 py-3.5 text-sm font-black text-white shadow-lg shadow-emerald-600/20 transition hover:bg-emerald-700"
                        >
                          <Award size={18} />
                          View Certificate
                        </Link>
                      ) : (
                        <Link
                          href={`/courses/${item.course.id}`}
                          className="inline-flex items-center justify-center gap-2 rounded-xl bg-blue-600 px-6 py-3.5 text-sm font-black text-white transition hover:bg-blue-700"
                        >
                          Open Course
                          <ArrowRight
                            size={18}
                          />
                        </Link>
                      )}

                      <Link
                        href={`/courses/${item.course.id}`}
                        className="inline-flex items-center justify-center gap-2 rounded-xl border border-slate-200 px-6 py-3.5 text-sm font-bold text-slate-700 transition hover:border-blue-300 hover:bg-blue-50 hover:text-blue-700"
                      >
                        Course Details
                      </Link>
                    </div>
                  </div>
                </div>
              </article>
            );
          }
        )}
      </div>
    </section>
  );
}

// ==========================================================
// SMALL PLAY ICON
// ==========================================================

function PlayIcon() {
  return (
    <svg
      width="16"
      height="16"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <path
        d="M8 5.5V18.5L18.5 12L8 5.5Z"
        fill="currentColor"
      />
    </svg>
  );
}