"use client";

import Link from "next/link";
import {
  BookOpen,
  PlayCircle,
  TrendingUp,
  ArrowRight,
} from "lucide-react";

type Props = {
  courseTitle: string;
  courseId: string | null;
  nextLessonId: string | null;
  progress: number;
  completedLessons: number;
  totalLessons: number;
};

export default function ContinueLearning({
  courseTitle,
  courseId,
  nextLessonId,
  progress,
  completedLessons,
  totalLessons,
}: Props) {
  const safeProgress = Math.min(
    100,
    Math.max(0, progress)
  );

  const remainingLessons = Math.max(
    0,
    totalLessons - completedLessons
  );

  const continueHref =
    courseId && nextLessonId
      ? `/courses/${courseId}/lesson/${nextLessonId}`
      : courseId
      ? `/courses/${courseId}`
      : "/courses";

  const hasCourse =
    Boolean(courseId);

  return (
    <section className="overflow-hidden rounded-3xl bg-gradient-to-r from-blue-700 via-indigo-700 to-cyan-700 p-6 text-white shadow-xl sm:p-8">
      <div className="flex flex-col gap-8 lg:flex-row lg:items-center lg:justify-between">

        {/* ==================================================
            LEFT
        ================================================== */}

        <div className="min-w-0 flex-1">

          <span className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 px-4 py-2 text-sm font-bold backdrop-blur">
            <TrendingUp size={17} />

            Continue Learning
          </span>

          <h2 className="mt-5 text-2xl font-black tracking-tight sm:text-3xl">
            {courseTitle}
          </h2>

          <p className="mt-3 max-w-2xl text-sm leading-7 text-blue-100 sm:text-base">
            {hasCourse
              ? "Continue from where you stopped and keep building your ICU knowledge."
              : "Enroll in a course to start your ICU learning journey."}
          </p>

          {/* Progress */}

          <div className="mt-7 max-w-2xl">

            <div className="mb-2 flex items-center justify-between text-sm font-bold">
              <span>
                Course Progress
              </span>

              <span>
                {safeProgress}%
              </span>
            </div>

            <div className="h-3 overflow-hidden rounded-full bg-white/15">
              <div
                className="h-full rounded-full bg-white shadow-sm transition-all duration-700"
                style={{
                  width: `${safeProgress}%`,
                }}
              />
            </div>

            <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-xs text-blue-100 sm:text-sm">
              <span>
                {completedLessons} /{" "}
                {totalLessons} lessons completed
              </span>

              <span>
                {remainingLessons} lessons remaining
              </span>
            </div>

          </div>

        </div>

        {/* ==================================================
            RESUME CARD
        ================================================== */}

        <div className="w-full shrink-0 rounded-3xl bg-white p-6 text-slate-900 shadow-2xl lg:w-96">

          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-blue-50 text-blue-700">
            <BookOpen size={30} />
          </div>

          <h3 className="mt-5 text-xl font-black sm:text-2xl">
            {hasCourse
              ? "Resume Course"
              : "Start Learning"}
          </h3>

          <p className="mt-2 text-sm leading-6 text-slate-500">
            {hasCourse
              ? "Pick up where you left off and continue your learning."
              : "Explore our ICU courses and choose a program to begin."}
          </p>

          <Link
            href={continueHref}
            className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-blue-700 px-5 py-3.5 text-sm font-black text-white shadow-lg shadow-blue-700/20 transition hover:bg-blue-800"
          >
            <PlayCircle size={19} />

            {hasCourse
              ? "Continue Learning"
              : "Explore Courses"}

            <ArrowRight
              size={17}
              className="transition-transform group-hover:translate-x-1"
            />
          </Link>

          {hasCourse && (
            <p className="mt-3 text-center text-xs font-medium text-slate-400">
              Your next lesson will open automatically.
            </p>
          )}

        </div>

      </div>
    </section>
  );
}