"use client";

import Script from "next/script";
import { useRouter } from "next/navigation";
import { useState } from "react";
import {
  CheckCircle2,
  CreditCard,
  Loader2,
  ShieldCheck,
} from "lucide-react";

type Props = {
  courseId: string;
  courseTitle: string;
  price: number;
  isLoggedIn: boolean;
  customerName?: string;
  customerEmail?: string;
};

type CreateOrderResponse = {
  success?: boolean;
  orderId?: string;
  amount?: number;
  currency?: string;
  keyId?: string;
  paymentId?: string;

  alreadyPurchased?: boolean;
  alreadyEnrolled?: boolean;

  message?: string;
};

type VerifyResponse = {
  success?: boolean;
  message?: string;
  paymentId?: string;
  enrollmentId?: string;
  alreadyProcessed?: boolean;
};

type RazorpayResponse = {
  razorpay_payment_id: string;
  razorpay_order_id: string;
  razorpay_signature: string;
};

type RazorpayOptions = {
  key: string;
  amount: number;
  currency: string;
  name: string;
  description: string;
  order_id: string;

  prefill?: {
    name?: string;
    email?: string;
  };

  theme?: {
    color?: string;
  };

  modal?: {
    ondismiss?: () => void;
  };

  handler: (
    response: RazorpayResponse
  ) => void | Promise<void>;
};

declare global {
  interface Window {
    Razorpay: new (
      options: RazorpayOptions
    ) => {
      open: () => void;
    };
  }
}

export default function BuyNowButton({
  courseId,
  courseTitle,
  price,
  isLoggedIn,
  customerName,
  customerEmail,
}: Props) {
  const router = useRouter();

  const [loading, setLoading] = useState(false);
  const [scriptLoaded, setScriptLoaded] =
    useState(false);
  const [error, setError] = useState("");

  const handleBuyNow = async () => {
    setError("");

    // ======================================================
    // 1. LOGIN CHECK
    // ======================================================

    if (!isLoggedIn) {
      router.push(
        `/login?callbackUrl=${encodeURIComponent(
          `/courses/${courseId}`
        )}`
      );

      return;
    }

    // ======================================================
    // 2. RAZORPAY SCRIPT CHECK
    // ======================================================

    if (
      !scriptLoaded ||
      typeof window === "undefined" ||
      !window.Razorpay
    ) {
      setError(
        "Payment system is still loading. Please try again in a moment."
      );

      return;
    }

    // ======================================================
    // 3. PRICE CHECK
    // ======================================================

    if (
      !Number.isFinite(price) ||
      price <= 0
    ) {
      setError("Invalid course price.");

      return;
    }

    try {
      setLoading(true);

      // ====================================================
      // 4. CREATE RAZORPAY ORDER
      // ====================================================

      const orderResponse = await fetch(
        "/api/payments/create-order",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          cache: "no-store",
          body: JSON.stringify({
            courseId,
          }),
        }
      );

      const orderData =
        (await orderResponse.json()) as CreateOrderResponse;

      console.log(
        "RAZORPAY CREATE ORDER RESPONSE:",
        orderData
      );

      // ====================================================
      // 5. HANDLE SERVER ERROR
      // ====================================================

      if (!orderResponse.ok) {
        if (orderData.alreadyPurchased) {
          router.push(
            `/courses/${courseId}`
          );

          router.refresh();

          return;
        }

        throw new Error(
          orderData.message ||
            "Unable to create payment order."
        );
      }

      // ====================================================
      // 6. ALREADY PURCHASED
      //
      // This is important because an existing Enrollment
      // alone does NOT mean payment is complete.
      //
      // Server returns alreadyPurchased ONLY when
      // a verified SUCCESS payment already exists.
      // ====================================================

      if (orderData.alreadyPurchased) {
        router.push(
          `/courses/${courseId}`
        );

        router.refresh();

        return;
      }

      // ====================================================
      // 7. VALIDATE RAZORPAY ORDER
      // ====================================================

      if (
        !orderData.success ||
        !orderData.orderId ||
        !orderData.amount ||
        !orderData.currency ||
        !orderData.keyId
      ) {
        console.error(
          "INVALID RAZORPAY ORDER RESPONSE:",
          orderData
        );

        throw new Error(
          orderData.message ||
            "Invalid payment order received from server."
        );
      }

      // ====================================================
      // 8. VERIFY AMOUNT FROM SERVER
      // ====================================================

      if (
        !Number.isSafeInteger(
          orderData.amount
        ) ||
        orderData.amount <= 0
      ) {
        throw new Error(
          "Invalid payment amount received from server."
        );
      }

      if (
        orderData.currency !== "INR"
      ) {
        throw new Error(
          "Unsupported payment currency."
        );
      }

      // ====================================================
      // 9. RAZORPAY CHECKOUT OPTIONS
      // ====================================================

      const options: RazorpayOptions = {
        key: orderData.keyId,

        amount: orderData.amount,

        currency:
          orderData.currency,

        name: "ICU Learning Portal",

        description:
          courseTitle,

        order_id:
          orderData.orderId,

        prefill: {
          name:
            customerName || "",
          email:
            customerEmail || "",
        },

        theme: {
          color: "#0891b2",
        },

        modal: {
          ondismiss: () => {
            setLoading(false);
          },
        },

        // ==================================================
        // 10. RAZORPAY SUCCESS CALLBACK
        // ==================================================

        handler: async (
          response: RazorpayResponse
        ) => {
          try {
            setError("");

            console.log(
              "RAZORPAY PAYMENT RESPONSE RECEIVED:",
              {
                orderId:
                  response.razorpay_order_id,
                paymentId:
                  response.razorpay_payment_id,
              }
            );

            // ==============================================
            // 11. SERVER-SIDE PAYMENT VERIFICATION
            // ==============================================

            const verifyResponse =
              await fetch(
                "/api/payments/verify",
                {
                  method: "POST",
                  headers: {
                    "Content-Type":
                      "application/json",
                  },
                  cache: "no-store",
                  body: JSON.stringify({
                    courseId,

                    razorpayOrderId:
                      response.razorpay_order_id,

                    razorpayPaymentId:
                      response.razorpay_payment_id,

                    razorpaySignature:
                      response.razorpay_signature,
                  }),
                }
              );

            const verifyData =
              (await verifyResponse.json()) as VerifyResponse;

            console.log(
              "RAZORPAY VERIFY RESPONSE:",
              verifyData
            );

            // ==============================================
            // 12. VERIFICATION FAILED
            // ==============================================

            if (
              !verifyResponse.ok ||
              !verifyData.success
            ) {
              throw new Error(
                verifyData.message ||
                  "Payment verification failed."
              );
            }

            // ==============================================
            // 13. PAYMENT VERIFIED
            //
            // Only now refresh the course page.
            // The server has already:
            //
            // SUCCESS payment
            // +
            // Enrollment
            //
            // before returning success.
            // ==============================================

            router.push(
              `/courses/${courseId}`
            );

            router.refresh();
          } catch (
            verificationError
          ) {
            console.error(
              "PAYMENT VERIFICATION ERROR:",
              verificationError
            );

            setError(
              verificationError instanceof
                Error
                ? verificationError.message
                : "Payment verification failed."
            );

            setLoading(false);
          }
        },
      };

      // ====================================================
      // 14. OPEN RAZORPAY CHECKOUT
      // ====================================================

      const razorpay =
        new window.Razorpay(
          options
        );

      razorpay.open();
    } catch (paymentError) {
      console.error(
        "RAZORPAY CHECKOUT ERROR:",
        paymentError
      );

      setError(
        paymentError instanceof Error
          ? paymentError.message
          : "Unable to start payment."
      );

      setLoading(false);
    }
  };

  return (
    <>
      <Script
        src="https://checkout.razorpay.com/v1/checkout.js"
        strategy="afterInteractive"
        onLoad={() => {
          setScriptLoaded(true);
        }}
        onError={() => {
          setError(
            "Unable to load Razorpay payment system."
          );
        }}
      />

      <div className="w-full max-w-md">
        <button
          type="button"
          onClick={handleBuyNow}
          disabled={loading}
          className="
            flex
            w-full
            items-center
            justify-center
            gap-3
            rounded-2xl
            bg-gradient-to-r
            from-cyan-600
            via-blue-600
            to-indigo-600
            px-7
            py-4
            text-lg
            font-bold
            text-white
            shadow-xl
            shadow-blue-600/20
            transition
            hover:from-cyan-700
            hover:via-blue-700
            hover:to-indigo-700
            disabled:cursor-not-allowed
            disabled:opacity-60
          "
        >
          {loading ? (
            <>
              <Loader2
                size={22}
                className="animate-spin"
              />

              Processing...
            </>
          ) : (
            <>
              <CreditCard size={22} />

              {isLoggedIn
                ? `Buy Now • ₹${price.toLocaleString(
                    "en-IN"
                  )}`
                : "Login to Purchase"}
            </>
          )}
        </button>

        <div className="mt-4 flex flex-wrap items-center justify-center gap-4 text-xs text-slate-500">
          <span className="inline-flex items-center gap-1.5">
            <ShieldCheck
              size={15}
              className="text-emerald-600"
            />

            Secure Payment
          </span>

          <span className="inline-flex items-center gap-1.5">
            <CheckCircle2
              size={15}
              className="text-emerald-600"
            />

            Instant Access
          </span>

          <span>
            UPI • Cards • Net Banking
          </span>
        </div>

        {error && (
          <div className="mt-4 rounded-xl border border-red-200 bg-red-50 p-4 text-sm font-medium text-red-700">
            {error}
          </div>
        )}
      </div>
    </>
  );
}