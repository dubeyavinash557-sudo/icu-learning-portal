import { NextResponse } from "next/server";
import { auth } from "@/auth";
import prisma from "@/lib/prisma";

export async function GET() {
  try {
    // ==========================================================
    // 1. AUTHENTICATION
    // ==========================================================

    const session = await auth();

    if (!session?.user?.email) {
      return NextResponse.json(
        {
          message: "Unauthorized",
        },
        {
          status: 401,
        }
      );
    }

    // ==========================================================
    // 2. FIND CURRENT USER
    // ==========================================================

    const user = await prisma.user.findUnique({
      where: {
        email: session.user.email,
      },
      select: {
        id: true,
      },
    });

    if (!user) {
      return NextResponse.json(
        {
          message: "User not found",
        },
        {
          status: 404,
        }
      );
    }

    // ==========================================================
    // 3. LOAD ENROLLMENTS + COURSE LESSONS
    // ==========================================================

    const enrollments =
      await prisma.enrollment.findMany({
        where: {
          userId: user.id,
        },

        include: {
          course: {
            include: {
              lessons: {
                orderBy: {
                  lessonOrder: "asc",
                },
              },
            },
          },
        },

        orderBy: {
          enrolledAt: "desc",
        },
      });

    // ==========================================================
    // 4. LOAD ALL USER LESSON PROGRESS
    //
    // One query instead of querying every course separately.
    // ==========================================================

    const lessonProgress =
      await prisma.lessonProgress.findMany({
        where: {
          userId: user.id,
        },

        select: {
          lessonId: true,
          completed: true,
          completedAt: true,
        },
      });

    // ==========================================================
    // 5. LOAD USER CERTIFICATES
    // ==========================================================

    const certificates =
      await prisma.certificate.findMany({
        where: {
          userId: user.id,
        },

        select: {
          id: true,
          courseId: true,
          certificateNo: true,
          issuedAt: true,
        },
      });

    // ==========================================================
    // 6. CREATE QUICK LOOKUPS
    // ==========================================================

    const completedLessonIds =
      new Set<string>();

    for (const progress of lessonProgress) {
      if (progress.completed) {
        completedLessonIds.add(
          progress.lessonId
        );
      }
    }

    const certificateByCourse =
      new Map<
        string,
        {
          id: string;
          certificateNo: string;
          issuedAt: Date;
        }
      >();

    for (const certificate of certificates) {
      certificateByCourse.set(
        certificate.courseId,
        {
          id: certificate.id,
          certificateNo:
            certificate.certificateNo,
          issuedAt: certificate.issuedAt,
        }
      );
    }

    // ==========================================================
    // 7. BUILD REAL COURSE DATA
    // ==========================================================

    const courses = enrollments.map(
      (enrollment) => {
        const course =
          enrollment.course;

        const totalLessons =
          course.lessons.length;

        const completedLessons =
          course.lessons.filter((lesson) =>
            completedLessonIds.has(
              lesson.id
            )
          ).length;

        const remainingLessons =
          Math.max(
            totalLessons -
              completedLessons,
            0
          );

        const calculatedProgress =
          totalLessons > 0
            ? Math.round(
                (completedLessons /
                  totalLessons) *
                  100
              )
            : 0;

        const progress = Math.min(
          100,
          Math.max(
            calculatedProgress,
            0
          )
        );

        const completed =
          totalLessons > 0 &&
          completedLessons >=
            totalLessons;

        // ======================================================
        // NEXT INCOMPLETE LESSON
        // ======================================================

        const nextLesson =
          course.lessons.find(
            (lesson) =>
              !completedLessonIds.has(
                lesson.id
              )
          ) ?? null;

        // ======================================================
        // CERTIFICATE
        // ======================================================

        const certificate =
          certificateByCourse.get(
            course.id
          ) ?? null;

        return {
          id: enrollment.id,

          enrolledAt:
            enrollment.enrolledAt,

          progress,

          completed,

          totalLessons,

          completedLessons,

          remainingLessons,

          nextLesson: nextLesson
            ? {
                id: nextLesson.id,
                title: nextLesson.title,
                lessonOrder:
                  nextLesson.lessonOrder,
              }
            : null,

          certificate: certificate
            ? {
                id: certificate.id,
                certificateNo:
                  certificate.certificateNo,
                issuedAt:
                  certificate.issuedAt,
              }
            : null,

          course: {
            id: course.id,
            title: course.title,
            slug: course.slug,
            image: course.image,
            description:
              course.description,
            instructor:
              course.instructor,
            rating: course.rating,
            duration:
              course.duration,
            language:
              course.language,
            level:
              course.level,
            price: course.price,
            isPremium:
              course.isPremium,

            lessons: course.lessons.map(
              (lesson) => ({
                id: lesson.id,
                title: lesson.title,
                lessonOrder:
                  lesson.lessonOrder,
                duration:
                  lesson.duration,
              })
            ),
          },
        };
      }
    );

    // ==========================================================
    // 8. RESPONSE
    // ==========================================================

    return NextResponse.json({
      success: true,
      courses,
    });
  } catch (error) {
    console.error(
      "MY COURSES API ERROR:",
      error
    );

    return NextResponse.json(
      {
        message:
          "Unable to load your courses.",
      },
      {
        status: 500,
      }
    );
  }
}