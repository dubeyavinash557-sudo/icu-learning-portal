import crypto from "crypto";
import { NextResponse } from "next/server";

import { auth } from "@/auth";
import prisma from "@/lib/prisma";
import razorpay from "@/lib/razorpay";

export const runtime = "nodejs";

// ============================================================
// TYPES
// ============================================================

type VerifyRequestBody = {
  courseId?: unknown;
  razorpayOrderId?: unknown;
  razorpayPaymentId?: unknown;
  razorpaySignature?: unknown;
};

type RazorpayPayment = {
  id?: unknown;
  order_id?: unknown;
  amount?: unknown;
  currency?: unknown;
  status?: unknown;
  method?: unknown;
};

// ============================================================
// HELPERS
// ============================================================

function isNonEmptyString(
  value: unknown
): value is string {
  return (
    typeof value === "string" &&
    value.trim().length > 0
  );
}

// ------------------------------------------------------------
// Timing-safe string comparison
// ------------------------------------------------------------

function safeCompare(
  expected: string,
  received: string
): boolean {
  const expectedBuffer = Buffer.from(
    expected,
    "utf8"
  );

  const receivedBuffer = Buffer.from(
    received,
    "utf8"
  );

  if (
    expectedBuffer.length !==
    receivedBuffer.length
  ) {
    return false;
  }

  return crypto.timingSafeEqual(
    expectedBuffer,
    receivedBuffer
  );
}

// ------------------------------------------------------------
// Generate Razorpay checkout signature
//
// HMAC-SHA256:
//
// order_id|payment_id
//
// using RAZORPAY_KEY_SECRET
// ------------------------------------------------------------

function generatePaymentSignature(
  orderId: string,
  paymentId: string,
  secret: string
): string {
  return crypto
    .createHmac(
      "sha256",
      secret
    )
    .update(
      `${orderId}|${paymentId}`,
      "utf8"
    )
    .digest("hex");
}

// ------------------------------------------------------------
// Convert INR to paise safely
// ------------------------------------------------------------

function rupeesToPaise(
  amount: number
): number | null {
  if (
    !Number.isFinite(amount) ||
    amount < 0
  ) {
    return null;
  }

  const paise = Math.round(
    amount * 100
  );

  if (
    !Number.isSafeInteger(paise)
  ) {
    return null;
  }

  return paise;
}

// ============================================================
// POST
// ============================================================

export async function POST(
  request: Request
) {
  try {
    // ========================================================
    // 1. AUTHENTICATION
    // ========================================================

    const session = await auth();

    if (!session?.user?.email) {
      return NextResponse.json(
        {
          success: false,
          message: "Unauthorized.",
        },
        {
          status: 401,
        }
      );
    }

    // ========================================================
    // 2. READ REQUEST BODY
    // ========================================================

    let body: VerifyRequestBody;

    try {
      const parsedBody =
        (await request.json()) as unknown;

      if (
        typeof parsedBody !== "object" ||
        parsedBody === null
      ) {
        return NextResponse.json(
          {
            success: false,
            message:
              "Invalid payment data.",
          },
          {
            status: 400,
          }
        );
      }

      body =
        parsedBody as VerifyRequestBody;
    } catch {
      return NextResponse.json(
        {
          success: false,
          message:
            "Invalid request body.",
        },
        {
          status: 400,
        }
      );
    }

    // ========================================================
    // 3. VALIDATE CHECKOUT RESPONSE
    // ========================================================

    if (
      !isNonEmptyString(
        body.courseId
      ) ||
      !isNonEmptyString(
        body.razorpayOrderId
      ) ||
      !isNonEmptyString(
        body.razorpayPaymentId
      ) ||
      !isNonEmptyString(
        body.razorpaySignature
      )
    ) {
      return NextResponse.json(
        {
          success: false,
          message:
            "Incomplete payment verification data.",
        },
        {
          status: 400,
        }
      );
    }

    const courseId =
      body.courseId.trim();

    const razorpayOrderId =
      body.razorpayOrderId.trim();

    const razorpayPaymentId =
      body.razorpayPaymentId.trim();

    const razorpaySignature =
      body.razorpaySignature.trim();

    // ========================================================
    // 4. SERVER SECRET
    // ========================================================

    const keySecret =
      process.env.RAZORPAY_KEY_SECRET;

    if (!keySecret) {
      console.error(
        "RAZORPAY_KEY_SECRET is missing."
      );

      return NextResponse.json(
        {
          success: false,
          message:
            "Payment gateway is not configured.",
        },
        {
          status: 500,
        }
      );
    }

    // ========================================================
    // 5. FIND AUTHENTICATED USER
    // ========================================================

    const user =
      await prisma.user.findUnique({
        where: {
          email:
            session.user.email,
        },
        select: {
          id: true,
          email: true,
        },
      });

    if (!user) {
      return NextResponse.json(
        {
          success: false,
          message:
            "User not found.",
        },
        {
          status: 404,
        }
      );
    }

    // ========================================================
    // 6. FIND OUR PAYMENT RECORD
    // ========================================================

    const payment =
      await prisma.payment.findUnique({
        where: {
          razorpayOrderId,
        },
        select: {
          id: true,
          userId: true,
          courseId: true,
          amount: true,
          status: true,
          paymentMethod: true,
          razorpayOrderId: true,
          razorpayPaymentId: true,
          razorpaySignature: true,
          transactionId: true,
        },
      });

    if (!payment) {
      console.error(
        "PAYMENT ORDER NOT FOUND:",
        {
          razorpayOrderId,
          razorpayPaymentId,
          userId: user.id,
        }
      );

      return NextResponse.json(
        {
          success: false,
          message:
            "Payment order not found.",
        },
        {
          status: 404,
        }
      );
    }

    // ========================================================
    // 7. VERIFY PAYMENT OWNERSHIP
    // ========================================================

    if (
      payment.userId !==
      user.id
    ) {
      console.error(
        "PAYMENT OWNERSHIP MISMATCH:",
        {
          paymentId:
            payment.id,
          paymentUserId:
            payment.userId,
          currentUserId:
            user.id,
        }
      );

      return NextResponse.json(
        {
          success: false,
          message:
            "Access denied.",
        },
        {
          status: 403,
        }
      );
    }

    // ========================================================
    // 8. VERIFY PAYMENT COURSE
    // ========================================================

    if (
      payment.courseId !==
      courseId
    ) {
      console.error(
        "PAYMENT COURSE MISMATCH:",
        {
          paymentId:
            payment.id,
          paymentCourseId:
            payment.courseId,
          requestedCourseId:
            courseId,
        }
      );

      return NextResponse.json(
        {
          success: false,
          message:
            "Course does not match payment.",
        },
        {
          status: 400,
        }
      );
    }

        // ========================================================
    // 9. VERIFY DATABASE ORDER ID
    // ========================================================

    const serverOrderId =
      payment.razorpayOrderId;

    if (!serverOrderId) {
      console.error(
        "DATABASE RAZORPAY ORDER ID MISSING:",
        {
          paymentId:
            payment.id,
        }
      );

      return NextResponse.json(
        {
          success: false,
          message:
            "Payment order information is incomplete.",
        },
        {
          status: 400,
        }
      );
    }

    if (
      serverOrderId !==
      razorpayOrderId
    ) {
      console.error(
        "RAZORPAY ORDER ID MISMATCH:",
        {
          paymentId:
            payment.id,
          serverOrderId,
          callbackOrderId:
            razorpayOrderId,
        }
      );

      return NextResponse.json(
        {
          success: false,
          message:
            "Payment order verification failed.",
        },
        {
          status: 400,
        }
      );
    }

    // ========================================================
    // 10. FIND COURSE
    //
    // Course price is ALWAYS taken from the database.
    // ========================================================

    const course =
      await prisma.course.findUnique({
        where: {
          id: courseId,
        },
        select: {
          id: true,
          title: true,
          price: true,
          isPremium: true,
        },
      });

    if (!course) {
      return NextResponse.json(
        {
          success: false,
          message:
            "Course not found.",
        },
        {
          status: 404,
        }
      );
    }

    // ========================================================
    // 11. VERIFY PAID COURSE
    // ========================================================

    if (
      course.isPremium !== true ||
      !Number.isFinite(
        course.price
      ) ||
      course.price <= 0
    ) {
      return NextResponse.json(
        {
          success: false,
          message:
            "This course is not configured as a paid course.",
        },
        {
          status: 400,
        }
      );
    }

    // ========================================================
    // 12. CALCULATE EXPECTED AMOUNT
    // ========================================================

    const expectedAmountInPaise =
      rupeesToPaise(
        course.price
      );

    if (
      expectedAmountInPaise ===
      null ||
      expectedAmountInPaise <= 0
    ) {
      console.error(
        "INVALID COURSE PRICE:",
        {
          courseId,
          coursePrice:
            course.price,
        }
      );

      return NextResponse.json(
        {
          success: false,
          message:
            "Course payment amount is invalid.",
        },
        {
          status: 400,
        }
      );
    }

    // ========================================================
    // 13. VERIFY LOCAL PAYMENT AMOUNT
    //
    // Database amount = INR.
    // Compare using paise to avoid Float equality problems.
    // ========================================================

    const localPaymentAmountInPaise =
      rupeesToPaise(
        Number(payment.amount)
      );

    if (
      localPaymentAmountInPaise ===
      null ||
      localPaymentAmountInPaise !==
      expectedAmountInPaise
    ) {
      console.error(
        "LOCAL PAYMENT AMOUNT MISMATCH:",
        {
          paymentId:
            payment.id,
          paymentAmount:
            payment.amount,
          coursePrice:
            course.price,
          localPaymentAmountInPaise,
          expectedAmountInPaise,
        }
      );

      return NextResponse.json(
        {
          success: false,
          message:
            "Payment amount does not match the course price.",
        },
        {
          status: 400,
        }
      );
    }

    // ========================================================
    // 14. HANDLE ALREADY SUCCESSFUL PAYMENT
    //
    // This endpoint is idempotent.
    // ========================================================

    if (
      String(payment.status)
        .toUpperCase() ===
      "SUCCESS"
    ) {
      // ------------------------------------------------------
      // A successful payment cannot be associated with a
      // different Razorpay payment ID.
      // ------------------------------------------------------

      if (
        payment.razorpayPaymentId &&
        payment.razorpayPaymentId !==
          razorpayPaymentId
      ) {
        console.error(
          "SUCCESS PAYMENT PAYMENT-ID CONFLICT:",
          {
            paymentId:
              payment.id,
            existingPaymentId:
              payment.razorpayPaymentId,
            incomingPaymentId:
              razorpayPaymentId,
          }
        );

        return NextResponse.json(
          {
            success: false,
            message:
              "Payment record has already been processed.",
          },
          {
            status: 409,
          }
        );
      }

      const enrollment =
        await prisma.enrollment.findUnique(
          {
            where: {
              userId_courseId: {
                userId:
                  user.id,
                courseId,
              },
            },
            select: {
              id: true,
              progress: true,
              completed: true,
            },
          }
        );

      // ------------------------------------------------------
      // Restore missing enrollment.
      // ------------------------------------------------------

      if (!enrollment) {
        try {
          const restoredEnrollment =
            await prisma.enrollment.create(
              {
                data: {
                  userId:
                    user.id,
                  courseId,
                  progress: 0,
                  completed: false,
                },
                select: {
                  id: true,
                  progress: true,
                  completed: true,
                },
              }
            );

          console.log(
            "ENROLLMENT RESTORED FOR SUCCESSFUL PAYMENT:",
            {
              paymentId:
                payment.id,
              enrollmentId:
                restoredEnrollment.id,
              courseId,
              userId:
                user.id,
            }
          );

          return NextResponse.json(
            {
              success: true,
              alreadyVerified: true,
              message:
                "Payment was already verified. Course access restored.",
              paymentId:
                payment.id,
              enrollmentId:
                restoredEnrollment.id,
              progress:
                restoredEnrollment.progress,
              completed:
                restoredEnrollment.completed,
            },
            {
              status: 200,
            }
          );
        } catch (restoreError) {
          // Another concurrent request may have restored it.
          const existingEnrollment =
            await prisma.enrollment.findUnique(
              {
                where: {
                  userId_courseId: {
                    userId:
                      user.id,
                    courseId,
                  },
                },
                select: {
                  id: true,
                  progress: true,
                  completed: true,
                },
              }
            );

          if (!existingEnrollment) {
            throw restoreError;
          }

          return NextResponse.json(
            {
              success: true,
              alreadyVerified: true,
              message:
                "Payment was already verified. Course access is active.",
              paymentId:
                payment.id,
              enrollmentId:
                existingEnrollment.id,
              progress:
                existingEnrollment.progress,
              completed:
                existingEnrollment.completed,
            },
            {
              status: 200,
            }
          );
        }
      }

      return NextResponse.json(
        {
          success: true,
          alreadyVerified: true,
          message:
            "Payment was already verified.",
          paymentId:
            payment.id,
          enrollmentId:
            enrollment.id,
          progress:
            enrollment.progress,
          completed:
            enrollment.completed,
        },
        {
          status: 200,
        }
      );
    }

    // ========================================================
    // 15. PREVENT PAYMENT-ID REUSE
    // ========================================================

    if (
      payment.razorpayPaymentId &&
      payment.razorpayPaymentId !==
        razorpayPaymentId
    ) {
      console.error(
        "PAYMENT-ID REUSE DETECTED:",
        {
          paymentId:
            payment.id,
          existingPaymentId:
            payment.razorpayPaymentId,
          incomingPaymentId:
            razorpayPaymentId,
        }
      );

      return NextResponse.json(
        {
          success: false,
          message:
            "Payment record has already been processed.",
        },
        {
          status: 409,
        }
      );
    }

    // ========================================================
    // 16. GENERATE SERVER PAYMENT SIGNATURE
    // ========================================================

    const generatedSignature =
      generatePaymentSignature(
        serverOrderId,
        razorpayPaymentId,
        keySecret
      );

    // ========================================================
    // 17. VERIFY RAZORPAY CHECKOUT SIGNATURE
    // ========================================================

    const signaturesMatch =
      safeCompare(
        generatedSignature,
        razorpaySignature
      );

    if (!signaturesMatch) {
      console.error(
        "RAZORPAY SIGNATURE VERIFICATION FAILED:",
        {
          paymentId:
            payment.id,
          razorpayOrderId:
            serverOrderId,
          razorpayPaymentId,
        }
      );

      // IMPORTANT:
      //
      // Do NOT mark the local payment FAILED here.
      //
      // A malicious request with an invalid signature must
      // not be able to sabotage a legitimate pending payment.
      //

      return NextResponse.json(
        {
          success: false,
          message:
            "Payment signature verification failed.",
        },
        {
          status: 400,
        }
      );
    }

    // ========================================================
    // 18. FETCH PAYMENT DIRECTLY FROM RAZORPAY
    //
    // Additional server-side verification.
    // ========================================================

    let razorpayPayment:
      | RazorpayPayment
      | null = null;

    try {
      const fetchedPayment =
        await razorpay.payments.fetch(
          razorpayPaymentId
        );

      razorpayPayment =
        fetchedPayment as RazorpayPayment;
    } catch (razorpayError) {
      console.error(
        "RAZORPAY PAYMENT FETCH ERROR:",
        razorpayError
      );

      return NextResponse.json(
        {
          success: false,
          message:
            "Unable to confirm payment status with Razorpay.",
        },
        {
          status: 502,
        }
      );
    }

    if (!razorpayPayment) {
      return NextResponse.json(
        {
          success: false,
          message:
            "Unable to retrieve payment information.",
        },
        {
          status: 502,
        }
      );
    }

        // ========================================================
    // 19. VERIFY PAYMENT ID
    // ========================================================

    if (
      !isNonEmptyString(
        razorpayPayment.id
      ) ||
      razorpayPayment.id !==
        razorpayPaymentId
    ) {
      console.error(
        "RAZORPAY PAYMENT-ID MISMATCH:",
        {
          expected:
            razorpayPaymentId,
          received:
            razorpayPayment.id,
        }
      );

      return NextResponse.json(
        {
          success: false,
          message:
            "Razorpay payment verification failed.",
        },
        {
          status: 400,
        }
      );
    }

    // ========================================================
    // 20. VERIFY RAZORPAY ORDER
    // ========================================================

    if (
      !isNonEmptyString(
        razorpayPayment.order_id
      ) ||
      razorpayPayment.order_id !==
        serverOrderId
    ) {
      console.error(
        "RAZORPAY ORDER MISMATCH:",
        {
          paymentId:
            payment.id,
          expectedOrderId:
            serverOrderId,
          receivedOrderId:
            razorpayPayment.order_id,
        }
      );

      return NextResponse.json(
        {
          success: false,
          message:
            "Razorpay payment does not belong to this order.",
        },
        {
          status: 400,
        }
      );
    }

    // ========================================================
    // 21. VERIFY RAZORPAY AMOUNT
    //
    // Database amount = INR
    // Razorpay amount = paise
    // ========================================================

    const razorpayAmount =
      Number(
        razorpayPayment.amount
      );

    if (
      !Number.isSafeInteger(
        razorpayAmount
      ) ||
      razorpayAmount <= 0 ||
      razorpayAmount !==
        expectedAmountInPaise
    ) {
      console.error(
        "RAZORPAY PAYMENT AMOUNT MISMATCH:",
        {
          paymentId:
            payment.id,
          coursePrice:
            course.price,
          expectedAmountInPaise,
          razorpayAmount,
        }
      );

      return NextResponse.json(
        {
          success: false,
          message:
            "Razorpay payment amount does not match the course price.",
        },
        {
          status: 400,
        }
      );
    }

    // ========================================================
    // 22. VERIFY CURRENCY
    // ========================================================

    if (
      String(
        razorpayPayment.currency
      ).toUpperCase() !==
      "INR"
    ) {
      console.error(
        "RAZORPAY CURRENCY MISMATCH:",
        {
          paymentId:
            payment.id,
          currency:
            razorpayPayment.currency,
        }
      );

      return NextResponse.json(
        {
          success: false,
          message:
            "Unsupported payment currency.",
        },
        {
          status: 400,
        }
      );
    }

    // ========================================================
    // 23. VERIFY PAYMENT STATUS
    //
    // Only CAPTURED unlocks the course.
    // ========================================================

    const razorpayStatus =
      isNonEmptyString(
        razorpayPayment.status
      )
        ? razorpayPayment.status.toLowerCase()
        : "";

    if (
      razorpayStatus !==
      "captured"
    ) {
      console.warn(
        "RAZORPAY PAYMENT NOT CAPTURED:",
        {
          paymentId:
            payment.id,
          razorpayPaymentId,
          status:
            razorpayStatus ||
            "unknown",
        }
      );

      return NextResponse.json(
        {
          success: false,
          message:
            razorpayStatus ===
            "authorized"
              ? "Payment is authorized but not captured yet. Course access will be granted after capture."
              : `Payment is not captured. Current status: ${
                  razorpayStatus ||
                  "unknown"
                }.`,
        },
        {
          status: 400,
        }
      );
    }

    // ========================================================
    // 24. PAYMENT METHOD
    // ========================================================

    const paymentMethod =
      isNonEmptyString(
        razorpayPayment.method
      )
        ? razorpayPayment.method
        : "razorpay";

    // ========================================================
    // 25. ATOMIC PAYMENT + ENROLLMENT TRANSACTION
    //
    // Payment SUCCESS
    // +
    // Enrollment
    //
    // Both must succeed together.
    // ========================================================

    const result =
      await prisma.$transaction(
        async (tx) => {
          // --------------------------------------------------
          // Re-read payment inside transaction
          // --------------------------------------------------

          const currentPayment =
            await tx.payment.findUnique({
              where: {
                id: payment.id,
              },
              select: {
                id: true,
                userId: true,
                courseId: true,
                amount: true,
                status: true,
                razorpayOrderId:
                  true,
                razorpayPaymentId:
                  true,
                transactionId:
                  true,
              },
            });

          if (!currentPayment) {
            throw new Error(
              "Payment record no longer exists."
            );
          }

          // --------------------------------------------------
          // Verify ownership again
          // --------------------------------------------------

          if (
            currentPayment.userId !==
            user.id
          ) {
            throw new Error(
              "Payment ownership changed unexpectedly."
            );
          }

          // --------------------------------------------------
          // Verify course again
          // --------------------------------------------------

          if (
            currentPayment.courseId !==
            courseId
          ) {
            throw new Error(
              "Payment course changed unexpectedly."
            );
          }

          // --------------------------------------------------
          // Verify order again
          // --------------------------------------------------

          if (
            currentPayment.razorpayOrderId !==
            serverOrderId
          ) {
            throw new Error(
              "Payment order changed unexpectedly."
            );
          }

          // --------------------------------------------------
          // Verify amount again
          // --------------------------------------------------

          const currentPaymentAmountInPaise =
            rupeesToPaise(
              Number(
                currentPayment.amount
              )
            );

          if (
            currentPaymentAmountInPaise ===
              null ||
            currentPaymentAmountInPaise !==
              expectedAmountInPaise
          ) {
            throw new Error(
              "Payment amount changed unexpectedly."
            );
          }

          // --------------------------------------------------
          // CONCURRENT VERIFICATION
          // --------------------------------------------------

          if (
            String(
              currentPayment.status
            ).toUpperCase() ===
            "SUCCESS"
          ) {
            if (
              currentPayment.razorpayPaymentId &&
              currentPayment.razorpayPaymentId !==
                razorpayPaymentId
            ) {
              throw new Error(
                "Payment record has already been completed with a different payment ID."
              );
            }

            const existingEnrollment =
              await tx.enrollment.findUnique(
                {
                  where: {
                    userId_courseId: {
                      userId:
                        user.id,
                      courseId,
                    },
                  },
                  select: {
                    id: true,
                    progress: true,
                    completed: true,
                  },
                }
              );

            if (
              existingEnrollment
            ) {
              return {
                paymentId:
                  currentPayment.id,
                enrollmentId:
                  existingEnrollment.id,
                progress:
                  existingEnrollment.progress,
                completed:
                  existingEnrollment.completed,
                alreadyProcessed:
                  true,
              };
            }

            const restoredEnrollment =
              await tx.enrollment.upsert({
                where: {
                  userId_courseId: {
                    userId:
                      user.id,
                    courseId,
                  },
                },
                update: {},
                create: {
                  userId:
                    user.id,
                  courseId,
                  progress: 0,
                  completed: false,
                },
                select: {
                  id: true,
                  progress: true,
                  completed: true,
                },
              });

            return {
              paymentId:
                currentPayment.id,
              enrollmentId:
                restoredEnrollment.id,
              progress:
                restoredEnrollment.progress,
              completed:
                restoredEnrollment.completed,
              alreadyProcessed:
                true,
            };
          }

          // --------------------------------------------------
          // PAYMENT-ID REUSE PROTECTION
          // --------------------------------------------------

          if (
            currentPayment.razorpayPaymentId &&
            currentPayment.razorpayPaymentId !==
              razorpayPaymentId
          ) {
            throw new Error(
              "Payment record already contains a different Razorpay payment ID."
            );
          }

                    // --------------------------------------------------
          // IMPORTANT CONCURRENCY GUARD
          //
          // Only transition the payment to SUCCESS when it
          // is still non-successful and has no conflicting
          // Razorpay payment ID.
          //
          // This prevents two simultaneous verification
          // requests from silently overwriting each other.
          // --------------------------------------------------

          const paymentUpdate =
            await tx.payment.updateMany({
              where: {
                id: payment.id,
                userId:
                  user.id,
                courseId,
                status: {
                  not: "SUCCESS",
                },
                OR: [
                  {
                    razorpayPaymentId:
                      null,
                  },
                  {
                    razorpayPaymentId:
                      razorpayPaymentId,
                  },
                ],
              },
              data: {
                status: "SUCCESS",
                paymentMethod,
                razorpayPaymentId,
                razorpaySignature,
                transactionId:
                  razorpayPaymentId,
              },
            });

          if (
            paymentUpdate.count !==
            1
          ) {
            // ------------------------------------------------
            // Another request may have completed the payment
            // between our read and update.
            // ------------------------------------------------

            const latestPayment =
              await tx.payment.findUnique({
                where: {
                  id: payment.id,
                },
                select: {
                  id: true,
                  status: true,
                  razorpayPaymentId:
                    true,
                },
              });

            if (
              latestPayment &&
              String(
                latestPayment.status
              ).toUpperCase() ===
                "SUCCESS"
            ) {
              if (
                latestPayment.razorpayPaymentId &&
                latestPayment.razorpayPaymentId !==
                  razorpayPaymentId
              ) {
                throw new Error(
                  "Payment was completed concurrently with a different Razorpay payment ID."
                );
              }

              const existingEnrollment =
                await tx.enrollment.findUnique(
                  {
                    where: {
                      userId_courseId: {
                        userId:
                          user.id,
                        courseId,
                      },
                    },
                    select: {
                      id: true,
                      progress: true,
                      completed: true,
                    },
                  }
                );

              if (
                existingEnrollment
              ) {
                return {
                  paymentId:
                    latestPayment.id,
                  enrollmentId:
                    existingEnrollment.id,
                  progress:
                    existingEnrollment.progress,
                  completed:
                    existingEnrollment.completed,
                  alreadyProcessed:
                    true,
                };
              }

              const restoredEnrollment =
                await tx.enrollment.upsert({
                  where: {
                    userId_courseId: {
                      userId:
                        user.id,
                      courseId,
                    },
                  },
                  update: {},
                  create: {
                    userId:
                      user.id,
                    courseId,
                    progress: 0,
                    completed:
                      false,
                  },
                  select: {
                    id: true,
                    progress: true,
                    completed: true,
                  },
                });

              return {
                paymentId:
                  latestPayment.id,
                enrollmentId:
                  restoredEnrollment.id,
                progress:
                  restoredEnrollment.progress,
                completed:
                  restoredEnrollment.completed,
                alreadyProcessed:
                  true,
              };
            }

            throw new Error(
              "Payment could not be safely finalized."
            );
          }

          // --------------------------------------------------
          // CREATE / PRESERVE ENROLLMENT
          // --------------------------------------------------

          const enrollment =
            await tx.enrollment.upsert({
              where: {
                userId_courseId: {
                  userId:
                    user.id,
                  courseId,
                },
              },
              update: {},
              create: {
                userId:
                  user.id,
                courseId,
                progress: 0,
                completed:
                  false,
              },
              select: {
                id: true,
                progress: true,
                completed: true,
              },
            });

          return {
            paymentId:
              payment.id,
            enrollmentId:
              enrollment.id,
            progress:
              enrollment.progress,
            completed:
              enrollment.completed,
            alreadyProcessed:
              false,
          };
        }
      );

    // ========================================================
    // 26. SUCCESS LOG
    //
    // Never log secret/signature values.
    // ========================================================

    console.log(
      "RAZORPAY PAYMENT VERIFIED SUCCESSFULLY:",
      {
        paymentId:
          result.paymentId,
        razorpayOrderId:
          serverOrderId,
        razorpayPaymentId,
        courseId,
        userId:
          user.id,
        enrollmentId:
          result.enrollmentId,
        alreadyProcessed:
          result.alreadyProcessed,
      }
    );

    // ========================================================
    // 27. FINAL SUCCESS RESPONSE
    // ========================================================

    return NextResponse.json(
      {
        success: true,
        message:
          result.alreadyProcessed
            ? "Payment was already verified. Course access is active."
            : "Payment verified successfully. Course unlocked.",
        paymentId:
          result.paymentId,
        enrollmentId:
          result.enrollmentId,
        progress:
          result.progress,
        completed:
          result.completed,
        alreadyProcessed:
          result.alreadyProcessed,
      },
      {
        status: 200,
      }
    );
  } catch (error) {
    // ========================================================
    // GLOBAL ERROR HANDLER
    // ========================================================

    console.error(
      "VERIFY RAZORPAY PAYMENT ERROR:",
      error
    );

    return NextResponse.json(
      {
        success: false,
        message:
          "Unable to verify payment.",
      },
      {
        status: 500,
      }
    );
  }
}

// ============================================================
// END OF RAZORPAY PAYMENT VERIFICATION ROUTE
// ============================================================
//
// The complete route.ts implementation is contained in
// Parts 1-4 above.
//
// DO NOT ADD ANY ADDITIONAL CODE HERE.
//
// ============================================================

/*
  FINAL FILE CHECKLIST

  1. runtime = "nodejs"
  2. auth() verifies the logged-in user
  3. Database payment order must already exist
  4. Payment ownership is verified
  5. Course ownership/payment relationship is verified
  6. Course price comes from Prisma
  7. INR amount is converted to paise
  8. Razorpay signature is verified server-side
  9. Razorpay payment is fetched server-side
 10. Razorpay payment ID is verified
 11. Razorpay order ID is verified
 12. Razorpay amount is verified
 13. INR currency is verified
 14. Only "captured" unlocks the course
 15. Payment + enrollment are handled atomically
 16. Existing enrollment progress is preserved
 17. Successful payments are idempotent
 18. Conflicting payment IDs are rejected
 19. Invalid signatures cannot deliberately mark the
     payment record as FAILED
 20. No secret/signature values are written to logs
*/