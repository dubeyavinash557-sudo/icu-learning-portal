import crypto from "node:crypto";
import { NextResponse } from "next/server";
import { Prisma } from "@prisma/client";

import prisma from "@/lib/prisma";

export const runtime = "nodejs";

// ============================================================
// CONFIGURATION
// ============================================================

/**
 * Razorpay recommends rejecting webhook events that are
 * older than 5 minutes.
 */
const MAX_WEBHOOK_AGE_SECONDS = 5 * 60;

// ============================================================
// TYPES
// ============================================================

type RazorpayPaymentEntity = {
  id?: unknown;
  order_id?: unknown;
  amount?: unknown;
  currency?: unknown;
  status?: unknown;
  method?: unknown;
};

type RazorpayWebhookEvent = {
  entity?: unknown;
  event?: unknown;
  account_id?: unknown;
  created_at?: unknown;
  payload?: {
    payment?: {
      entity?: RazorpayPaymentEntity;
    };
  };
};

// ============================================================
// HELPERS
// ============================================================

function isNonEmptyString(value: unknown): value is string {
  return typeof value === "string" && value.trim().length > 0;
}

// ------------------------------------------------------------
// Timing-safe signature comparison
// ------------------------------------------------------------

function safeCompare(expected: string, received: string): boolean {
  const expectedBuffer = Buffer.from(expected, "utf8");
  const receivedBuffer = Buffer.from(received, "utf8");

  if (expectedBuffer.length !== receivedBuffer.length) {
    return false;
  }

  return crypto.timingSafeEqual(
    expectedBuffer,
    receivedBuffer
  );
}

// ------------------------------------------------------------
// Generate Razorpay webhook signature
//
// IMPORTANT:
// The ORIGINAL raw request body must be used.
// ------------------------------------------------------------

function generateWebhookSignature(
  rawBody: string,
  secret: string
): string {
  return crypto
    .createHmac("sha256", secret)
    .update(rawBody, "utf8")
    .digest("hex");
}

// ------------------------------------------------------------
// Prisma unique constraint helper
// ------------------------------------------------------------

function isUniqueConstraintError(
  error: unknown
): boolean {
  return (
    error instanceof
      Prisma.PrismaClientKnownRequestError &&
    error.code === "P2002"
  );
}

// ------------------------------------------------------------
// Safe internal response
// ------------------------------------------------------------

function internalServerError() {
  return NextResponse.json(
    {
      success: false,
      message: "Unable to process webhook.",
    },
    {
      status: 500,
    }
  );
}

// ------------------------------------------------------------
// Verify webhook timestamp
// ------------------------------------------------------------

function isWebhookTimestampValid(
  createdAt: unknown
): boolean {
  if (
    typeof createdAt !== "number" ||
    !Number.isSafeInteger(createdAt) ||
    createdAt <= 0
  ) {
    return false;
  }

  const now = Math.floor(Date.now() / 1000);

  const age = now - createdAt;

  /**
   * Reject:
   *
   * 1. Future timestamps
   * 2. Events older than the configured replay window
   */
  return (
    age >= 0 &&
    age <= MAX_WEBHOOK_AGE_SECONDS
  );
}

// ------------------------------------------------------------
// Convert INR amount to paise safely
// ------------------------------------------------------------

function amountToPaise(
  amount: unknown
): number | null {
  const numericAmount = Number(amount);

  if (
    !Number.isFinite(numericAmount) ||
    numericAmount <= 0
  ) {
    return null;
  }

  const paise = Math.round(
    numericAmount * 100
  );

  if (!Number.isSafeInteger(paise) || paise <= 0) {
    return null;
  }

  return paise;
}

// ============================================================
// POST
// ============================================================

export async function POST(
  request: Request
) {
  try {
    // ========================================================
    // 1. READ RAW BODY
    //
    // NEVER use request.json() before signature verification.
    // ========================================================

    const rawBody = await request.text();

    if (!rawBody) {
      console.error(
        "RAZORPAY WEBHOOK EMPTY BODY"
      );

      return NextResponse.json(
        {
          success: false,
          message: "Empty webhook body.",
        },
        {
          status: 400,
        }
      );
    }

    // ========================================================
    // 2. WEBHOOK SECRET
    // ========================================================

    const webhookSecret =
      process.env.RAZORPAY_WEBHOOK_SECRET?.trim();

    if (!webhookSecret) {
      console.error(
        "RAZORPAY_WEBHOOK_SECRET is missing."
      );

      return NextResponse.json(
        {
          success: false,
          message: "Webhook is not configured.",
        },
        {
          status: 500,
        }
      );
    }

    // ========================================================
    // 3. READ SIGNATURE
    // ========================================================

    const receivedSignature =
      request.headers.get(
        "x-razorpay-signature"
      );

    if (
      !isNonEmptyString(receivedSignature)
    ) {
      console.error(
        "RAZORPAY WEBHOOK SIGNATURE MISSING"
      );

      return NextResponse.json(
        {
          success: false,
          message:
            "Missing Razorpay webhook signature.",
        },
        {
          status: 400,
        }
      );
    }

    // ========================================================
    // 4. VERIFY SIGNATURE
    // ========================================================

    const expectedSignature =
      generateWebhookSignature(
        rawBody,
        webhookSecret
      );

    const signatureValid =
      safeCompare(
        expectedSignature,
        receivedSignature.trim()
      );

    if (!signatureValid) {
      console.error(
        "INVALID RAZORPAY WEBHOOK SIGNATURE"
      );

      return NextResponse.json(
        {
          success: false,
          message:
            "Invalid webhook signature.",
        },
        {
          status: 400,
        }
      );
    }

    // ========================================================
    // 5. EVENT ID
    //
    // Razorpay provides a unique event ID for idempotency.
    // ========================================================

    const eventId =
      request.headers.get(
        "x-razorpay-event-id"
      );

    if (!isNonEmptyString(eventId)) {
      console.error(
        "RAZORPAY WEBHOOK EVENT ID MISSING"
      );

      return NextResponse.json(
        {
          success: false,
          message:
            "Missing Razorpay event ID.",
        },
        {
          status: 400,
        }
      );
    }

    const normalizedEventId =
      eventId.trim();

    // ========================================================
    // 6. PARSE JSON
    //
    // Signature has already been verified.
    // ========================================================

    let event:
      RazorpayWebhookEvent;

    let payload:
      Prisma.InputJsonValue;

    try {
      const parsed =
        JSON.parse(rawBody) as unknown;

      if (
        typeof parsed !== "object" ||
        parsed === null ||
        Array.isArray(parsed)
      ) {
        return NextResponse.json(
          {
            success: false,
            message: "Invalid webhook JSON.",
          },
          {
            status: 400,
          }
        );
      }

      event =
        parsed as RazorpayWebhookEvent;

      payload =
        parsed as Prisma.InputJsonValue;
    } catch {
      console.error(
        "INVALID RAZORPAY WEBHOOK JSON"
      );

      return NextResponse.json(
        {
          success: false,
          message: "Invalid webhook JSON.",
        },
        {
          status: 400,
        }
      );
    }

    // ========================================================
    // 7. EVENT TYPE
    // ========================================================

    const eventType =
      isNonEmptyString(event.event)
        ? event.event.trim()
        : "";

    if (!eventType) {
      console.error(
        "RAZORPAY WEBHOOK EVENT TYPE MISSING"
      );

      return NextResponse.json(
        {
          success: false,
          message:
            "Webhook event type is missing.",
        },
        {
          status: 400,
        }
      );
    }

    // ========================================================
    // 8. VERIFY EVENT TIMESTAMP
    // ========================================================

    if (
      !isWebhookTimestampValid(
        event.created_at
      )
    ) {
      console.error(
        "RAZORPAY WEBHOOK TIMESTAMP INVALID OR TOO OLD:",
        {
          eventId:
            normalizedEventId,
          eventType,
          createdAt:
            event.created_at,
        }
      );

      return NextResponse.json(
        {
          success: false,
          message:
            "Webhook event is expired or invalid.",
        },
        {
          status: 400,
        }
      );
    }

    console.log(
      "RAZORPAY WEBHOOK RECEIVED:",
      {
        eventId:
          normalizedEventId,
        eventType,
      }
    );

    // ========================================================
    // 9. REGISTER EVENT
    //
    // eventId is UNIQUE in Prisma.
    // ========================================================

    let webhookEvent:
      | {
          id: string;
          eventId: string;
          processed: boolean;
        }
      | null = null;

    try {
      webhookEvent =
        await prisma.paymentWebhookEvent.create({
          data: {
            eventId:
              normalizedEventId,
            eventType,
            payload,
          },
          select: {
            id: true,
            eventId: true,
            processed: true,
          },
        });
    } catch (error) {
      if (
        !isUniqueConstraintError(error)
      ) {
        console.error(
          "PAYMENT WEBHOOK EVENT CREATE ERROR:",
          error
        );

        return internalServerError();
      }

      // ------------------------------------------------------
      // Existing event
      // ------------------------------------------------------

      webhookEvent =
        await prisma.paymentWebhookEvent.findUnique({
          where: {
            eventId:
              normalizedEventId,
          },
          select: {
            id: true,
            eventId: true,
            processed: true,
          },
        });

      if (!webhookEvent) {
        console.error(
          "WEBHOOK EVENT CONFLICT BUT RECORD NOT FOUND:",
          {
            eventId:
              normalizedEventId,
          }
        );

        return internalServerError();
      }

      if (webhookEvent.processed) {
        console.log(
          "RAZORPAY WEBHOOK ALREADY PROCESSED:",
          {
            eventId:
              normalizedEventId,
            eventType,
          }
        );

        return NextResponse.json(
          {
            success: true,
            duplicate: true,
            alreadyProcessed: true,
            message:
              "Webhook event already processed.",
          },
          {
            status: 200,
          }
        );
      }

      /**
       * Important:
       *
       * The event exists but is not processed.
       *
       * We continue below.
       *
       * A PostgreSQL row lock inside the transaction below
       * prevents two concurrent requests from processing the
       * same event simultaneously.
       */
    }

    // ========================================================
    // 10. SUPPORTED EVENTS
    // ========================================================

    const supportedEvents =
      new Set([
        "payment.captured",
        "payment.failed",
      ]);

    // ========================================================
    // 11. IGNORE UNSUPPORTED EVENTS
    // ========================================================

    if (
      !supportedEvents.has(eventType)
    ) {
      await prisma.paymentWebhookEvent.update({
        where: {
          eventId:
            normalizedEventId,
        },
        data: {
          processed: true,
          processedAt:
            new Date(),
        },
      });

      console.log(
        "RAZORPAY WEBHOOK IGNORED:",
        {
          eventId:
            normalizedEventId,
          eventType,
        }
      );

      return NextResponse.json(
        {
          success: true,
          ignored: true,
          event: eventType,
        },
        {
          status: 200,
        }
      );
    }

    // ========================================================
    // 12. EXTRACT PAYMENT ENTITY
    // ========================================================

    const paymentEntity =
      event.payload
        ?.payment
        ?.entity;

    if (!paymentEntity) {
      console.error(
        "RAZORPAY WEBHOOK PAYMENT ENTITY MISSING:",
        {
          eventId:
            normalizedEventId,
          eventType,
        }
      );

      /**
       * Do not mark processed.
       * Razorpay can retry the event.
       */

      return NextResponse.json(
        {
          success: false,
          message:
            "Payment entity is missing from webhook.",
        },
        {
          status: 400,
        }
      );
    }

    // ========================================================
    // 13. EXTRACT PAYMENT ID / ORDER ID
    // ========================================================

    const razorpayPaymentId =
      isNonEmptyString(
        paymentEntity.id
      )
        ? paymentEntity.id.trim()
        : "";

    const razorpayOrderId =
      isNonEmptyString(
        paymentEntity.order_id
      )
        ? paymentEntity.order_id.trim()
        : "";

    if (
      !razorpayPaymentId ||
      !razorpayOrderId
    ) {
      console.error(
        "RAZORPAY WEBHOOK PAYMENT DATA MISSING:",
        {
          eventId:
            normalizedEventId,
          eventType,
        }
      );

      return NextResponse.json(
        {
          success: false,
          message:
            "Payment information is missing from webhook.",
        },
        {
          status: 400,
        }
      );
    }

    // ========================================================
    // 14. SAVE RAZORPAY IDENTIFIERS
    // ========================================================

    await prisma.paymentWebhookEvent.update({
      where: {
        eventId:
          normalizedEventId,
      },
      data: {
        razorpayOrderId,
        razorpayPaymentId,
      },
    });

    // ========================================================
    // 15. FIND LOCAL PAYMENT
    // ========================================================

    const payment =
      await prisma.payment.findUnique({
        where: {
          razorpayOrderId,
        },
        select: {
          id: true,
          userId: true,
          courseId: true,
          amount: true,
          status: true,
          paymentMethod: true,
          razorpayOrderId: true,
          razorpayPaymentId: true,
          transactionId: true,
        },
      });

    if (!payment) {
      console.error(
        "PAYMENT RECORD NOT FOUND FOR WEBHOOK:",
        {
          eventId:
            normalizedEventId,
          eventType,
          razorpayOrderId,
          razorpayPaymentId,
        }
      );

      /**
       * Do not mark processed.
       * The local payment may become available before
       * Razorpay retries the webhook.
       */

      return NextResponse.json(
        {
          success: false,
          message:
            "Payment record not found.",
        },
        {
          status: 404,
        }
      );
    }

    // ========================================================
    // 16. COURSE VALIDATION
    // ========================================================

    const courseId =
      payment.courseId;

    if (!courseId) {
      console.error(
        "PAYMENT COURSE ID MISSING:",
        {
          eventId:
            normalizedEventId,
          paymentId:
            payment.id,
        }
      );

      return NextResponse.json(
        {
          success: false,
          message:
            "Payment is not associated with a course.",
        },
        {
          status: 400,
        }
      );
    }

    // ========================================================
    // 17. VERIFY LOCAL ORDER ID
    // ========================================================

    if (
      payment.razorpayOrderId !==
      razorpayOrderId
    ) {
      console.error(
        "RAZORPAY WEBHOOK ORDER MISMATCH:",
        {
          eventId:
            normalizedEventId,
          paymentId:
            payment.id,
          databaseOrderId:
            payment.razorpayOrderId,
          webhookOrderId:
            razorpayOrderId,
        }
      );

      return NextResponse.json(
        {
          success: false,
          message:
            "Payment order mismatch.",
        },
        {
          status: 400,
        }
      );
    }

    // ========================================================
    // 18. PAYMENT CAPTURED
    // ========================================================

    if (
      eventType ===
      "payment.captured"
    ) {
      // ======================================================
      // 18A. VERIFY PAYMENT STATUS
      // ======================================================

      const webhookStatus =
        isNonEmptyString(
          paymentEntity.status
        )
          ? paymentEntity.status
              .trim()
              .toLowerCase()
          : "";

      if (
        webhookStatus !==
        "captured"
      ) {
        console.error(
          "INVALID PAYMENT.CAPTURED STATUS:",
          {
            eventId:
              normalizedEventId,
            paymentId:
              payment.id,
            status:
              webhookStatus,
          }
        );

        return NextResponse.json(
          {
            success: false,
            message:
              "Invalid captured payment status.",
          },
          {
            status: 400,
          }
        );
      }

      // ======================================================
      // 18B. VERIFY PAYMENT ID
      // ======================================================

      if (
        payment.razorpayPaymentId &&
        payment.razorpayPaymentId !==
          razorpayPaymentId
      ) {
        console.error(
          "PAYMENT-ID CONFLICT:",
          {
            eventId:
              normalizedEventId,
            paymentId:
              payment.id,
            existingPaymentId:
              payment.razorpayPaymentId,
            incomingPaymentId:
              razorpayPaymentId,
          }
        );

        return NextResponse.json(
          {
            success: false,
            message:
              "Payment record has already been processed.",
          },
          {
            status: 409,
          }
        );
      }

      // ======================================================
      // 18C. VERIFY AMOUNT
      // ======================================================

      const receivedAmount =
        amountToPaise(
          paymentEntity.amount
        );

      const expectedAmount =
        amountToPaise(
          payment.amount
        );

      if (
        receivedAmount === null ||
        expectedAmount === null ||
        receivedAmount !==
          expectedAmount
      ) {
        console.error(
          "RAZORPAY WEBHOOK AMOUNT MISMATCH:",
          {
            eventId:
              normalizedEventId,
            paymentId:
              payment.id,
            expectedAmount,
            receivedAmount,
          }
        );

        return NextResponse.json(
          {
            success: false,
            message:
              "Webhook payment amount mismatch.",
          },
          {
            status: 400,
          }
        );
      }

      // ======================================================
      // 18D. VERIFY CURRENCY
      // ======================================================

      const webhookCurrency =
        isNonEmptyString(
          paymentEntity.currency
        )
          ? paymentEntity.currency
              .trim()
              .toUpperCase()
          : "";

      if (
        webhookCurrency !==
        "INR"
      ) {
        console.error(
          "RAZORPAY WEBHOOK CURRENCY MISMATCH:",
          {
            eventId:
              normalizedEventId,
            paymentId:
              payment.id,
            currency:
              paymentEntity.currency,
          }
        );

        return NextResponse.json(
          {
            success: false,
            message:
              "Webhook payment currency mismatch.",
          },
          {
            status: 400,
          }
        );
      }

      // ======================================================
      // 18E. PAYMENT METHOD
      // ======================================================

      const paymentMethod =
        isNonEmptyString(
          paymentEntity.method
        )
          ? paymentEntity.method.trim()
          : "razorpay";

      // ======================================================
      // 18F. ATOMIC TRANSACTION
      //
      // PostgreSQL row lock on PaymentWebhookEvent prevents
      // concurrent duplicate requests from processing the same
      // webhook event twice.
      // ======================================================

      const result =
        await prisma.$transaction(
          async (tx) => {
            // ------------------------------------------------
            // LOCK WEBHOOK EVENT
            // ------------------------------------------------

            const lockedEvents =
              await tx.$queryRaw<
                Array<{
                  id: string;
                }>
              >(
                Prisma.sql`
                  SELECT "id"
                  FROM "PaymentWebhookEvent"
                  WHERE "eventId" = ${normalizedEventId}
                  FOR UPDATE
                `
              );

            if (
              lockedEvents.length ===
              0
            ) {
              throw new Error(
                "Webhook event record no longer exists."
              );
            }

            // ------------------------------------------------
            // RE-READ WEBHOOK EVENT AFTER LOCK
            // ------------------------------------------------

            const currentWebhookEvent =
              await tx.paymentWebhookEvent.findUnique({
                where: {
                  eventId:
                    normalizedEventId,
                },
                select: {
                  id: true,
                  processed: true,
                },
              });

            if (
              !currentWebhookEvent
            ) {
              throw new Error(
                "Webhook event record no longer exists."
              );
            }

            // ------------------------------------------------
            // CONCURRENT REQUEST ALREADY PROCESSED IT
            // ------------------------------------------------

            if (
              currentWebhookEvent.processed
            ) {
              return {
                paymentId:
                  payment.id,
                enrollmentId:
                  null as string | null,
                progress:
                  null as number | null,
                completed:
                  null as boolean | null,
                alreadyProcessed:
                  true,
              };
            }

            // ------------------------------------------------
            // RE-READ PAYMENT
            // ------------------------------------------------

            const currentPayment =
              await tx.payment.findUnique({
                where: {
                  id:
                    payment.id,
                },
                select: {
                  id: true,
                  userId: true,
                  courseId: true,
                  amount: true,
                  status: true,
                  razorpayOrderId:
                    true,
                  razorpayPaymentId:
                    true,
                },
              });

            if (!currentPayment) {
              throw new Error(
                "Payment record no longer exists."
              );
            }

            // ------------------------------------------------
            // VERIFY OWNERSHIP
            // ------------------------------------------------

            if (
              currentPayment.userId !==
              payment.userId
            ) {
              throw new Error(
                "Payment ownership changed unexpectedly."
              );
            }

            if (
              currentPayment.courseId !==
              courseId
            ) {
              throw new Error(
                "Payment course changed unexpectedly."
              );
            }

            // ------------------------------------------------
            // VERIFY LOCAL AMOUNT
            // ------------------------------------------------

            const currentPaymentPaise =
              amountToPaise(
                currentPayment.amount
              );

            if (
              currentPaymentPaise ===
                null ||
              currentPaymentPaise !==
                expectedAmount
            ) {
              throw new Error(
                "Payment amount changed unexpectedly."
              );
            }

            // ------------------------------------------------
            // ALREADY SUCCESSFUL
            // ------------------------------------------------

            if (
              currentPayment.status
                .trim()
                .toUpperCase() ===
              "SUCCESS"
            ) {
              if (
                currentPayment.razorpayPaymentId &&
                currentPayment.razorpayPaymentId !==
                  razorpayPaymentId
              ) {
                throw new Error(
                  "Payment was already completed with a different payment ID."
                );
              }

              // ----------------------------------------------
              // PRESERVE EXISTING ENROLLMENT
              // ----------------------------------------------

              const enrollment =
                await tx.enrollment.findUnique({
                  where: {
                    userId_courseId: {
                      userId:
                        currentPayment.userId,
                      courseId,
                    },
                  },
                  select: {
                    id: true,
                    progress: true,
                    completed:
                      true,
                  },
                });

              // ----------------------------------------------
              // RESTORE MISSING ENROLLMENT
              // ----------------------------------------------

              const finalEnrollment =
                enrollment ??
                (await tx.enrollment.create({
                  data: {
                    userId:
                      currentPayment.userId,
                    courseId,
                    progress: 0,
                    completed:
                      false,
                  },
                  select: {
                    id: true,
                    progress: true,
                    completed:
                      true,
                  },
                }));

              // ----------------------------------------------
              // MARK WEBHOOK PROCESSED
              // ----------------------------------------------

              await tx.paymentWebhookEvent.update({
                where: {
                  eventId:
                    normalizedEventId,
                },
                data: {
                  processed:
                    true,
                  processedAt:
                    new Date(),
                },
              });

              return {
                paymentId:
                  currentPayment.id,
                enrollmentId:
                  finalEnrollment.id,
                progress:
                  finalEnrollment.progress,
                completed:
                  finalEnrollment.completed,
                alreadyProcessed:
                  true,
              };
            }

            // ------------------------------------------------
            // PREVENT PAYMENT ID REPLACEMENT
            // ------------------------------------------------

            if (
              currentPayment.razorpayPaymentId &&
              currentPayment.razorpayPaymentId !==
                razorpayPaymentId
            ) {
              throw new Error(
                "Payment record already contains a different Razorpay payment ID."
              );
            }

            // ------------------------------------------------
            // UPDATE PAYMENT
            // ------------------------------------------------

            const updatedPayment =
              await tx.payment.update({
                where: {
                  id:
                    payment.id,
                },
                data: {
                  status:
                    "SUCCESS",
                  paymentMethod,
                  razorpayPaymentId,
                  transactionId:
                    razorpayPaymentId,
                },
                select: {
                  id: true,
                },
              });

            // ------------------------------------------------
            // CREATE / PRESERVE ENROLLMENT
            // ------------------------------------------------

            const enrollment =
              await tx.enrollment.upsert({
                where: {
                  userId_courseId: {
                    userId:
                      payment.userId,
                    courseId,
                  },
                },
                update: {},
                create: {
                  userId:
                    payment.userId,
                  courseId,
                  progress: 0,
                  completed:
                    false,
                },
                select: {
                  id: true,
                  progress: true,
                  completed:
                    true,
                },
              });

            // ------------------------------------------------
            // MARK WEBHOOK PROCESSED
            // ------------------------------------------------

            await tx.paymentWebhookEvent.update({
              where: {
                eventId:
                  normalizedEventId,
              },
              data: {
                processed:
                  true,
                processedAt:
                  new Date(),
              },
            });

            return {
              paymentId:
                updatedPayment.id,
              enrollmentId:
                enrollment.id,
              progress:
                enrollment.progress,
              completed:
                enrollment.completed,
              alreadyProcessed:
                false,
            };
          }
        );

      // ======================================================
      // CONCURRENT DUPLICATE
      // ======================================================

      if (
        result.alreadyProcessed &&
        result.enrollmentId === null
      ) {
        console.log(
          "RAZORPAY WEBHOOK CONCURRENT DUPLICATE:",
          {
            eventId:
              normalizedEventId,
            eventType,
          }
        );

        return NextResponse.json(
          {
            success: true,
            duplicate: true,
            alreadyProcessed:
              true,
            message:
              "Webhook event already processed.",
          },
          {
            status: 200,
          }
        );
      }

      // ======================================================
      // SUCCESS LOG
      // ======================================================

      console.log(
        "RAZORPAY PAYMENT CAPTURED:",
        {
          eventId:
            normalizedEventId,
          razorpayOrderId,
          razorpayPaymentId,
          paymentId:
            result.paymentId,
          enrollmentId:
            result.enrollmentId,
          courseId,
          alreadyProcessed:
            result.alreadyProcessed,
        }
      );

      return NextResponse.json(
        {
          success: true,
          message:
            "Payment captured and course access granted.",
          paymentId:
            result.paymentId,
          enrollmentId:
            result.enrollmentId,
          progress:
            result.progress,
          completed:
            result.completed,
          alreadyProcessed:
            result.alreadyProcessed,
        },
        {
          status: 200,
        }
      );
    }

    // ========================================================
    // 19. PAYMENT FAILED
    // ========================================================

    if (
      eventType ===
      "payment.failed"
    ) {
      // ======================================================
      // VERIFY FAILED STATUS
      // ======================================================

      const webhookStatus =
        isNonEmptyString(
          paymentEntity.status
        )
          ? paymentEntity.status
              .trim()
              .toLowerCase()
          : "";

      if (
        webhookStatus !==
        "failed"
      ) {
        console.error(
          "INVALID PAYMENT.FAILED STATUS:",
          {
            eventId:
              normalizedEventId,
            paymentId:
              payment.id,
            status:
              webhookStatus,
          }
        );

        return NextResponse.json(
          {
            success: false,
            message:
              "Invalid failed payment status.",
          },
          {
            status: 400,
          }
        );
      }

      // ======================================================
      // ATOMIC FAILED PAYMENT HANDLING
      // ======================================================

      const result =
        await prisma.$transaction(
          async (tx) => {
            // ------------------------------------------------
            // LOCK WEBHOOK EVENT
            // ------------------------------------------------

            const lockedEvents =
              await tx.$queryRaw<
                Array<{
                  id: string;
                }>
              >(
                Prisma.sql`
                  SELECT "id"
                  FROM "PaymentWebhookEvent"
                  WHERE "eventId" = ${normalizedEventId}
                  FOR UPDATE
                `
              );

            if (
              lockedEvents.length ===
              0
            ) {
              throw new Error(
                "Webhook event record no longer exists."
              );
            }

            // ------------------------------------------------
            // RECHECK PROCESSED STATE
            // ------------------------------------------------

            const currentWebhookEvent =
              await tx.paymentWebhookEvent.findUnique({
                where: {
                  eventId:
                    normalizedEventId,
                },
                select: {
                  processed: true,
                },
              });

            if (
              !currentWebhookEvent
            ) {
              throw new Error(
                "Webhook event record no longer exists."
              );
            }

            if (
              currentWebhookEvent.processed
            ) {
              return {
                alreadyProcessed:
                  true,
              };
            }

            // ------------------------------------------------
            // RE-READ PAYMENT
            // ------------------------------------------------

            const currentPayment =
              await tx.payment.findUnique({
                where: {
                  id:
                    payment.id,
                },
                select: {
                  id: true,
                  status: true,
                  razorpayPaymentId:
                    true,
                },
              });

            if (!currentPayment) {
              throw new Error(
                "Payment record no longer exists."
              );
            }

            // ------------------------------------------------
            // NEVER DOWNGRADE SUCCESS
            // ------------------------------------------------

            if (
              currentPayment.status
                .trim()
                .toUpperCase() !==
              "SUCCESS"
            ) {
              await tx.payment.update({
                where: {
                  id:
                    currentPayment.id,
                },
                data: {
                  status:
                    "FAILED",
                  paymentMethod:
                    "razorpay",
                  razorpayPaymentId:
                    currentPayment.razorpayPaymentId ??
                    razorpayPaymentId,
                },
              });
            }

            // ------------------------------------------------
            // MARK WEBHOOK PROCESSED
            // ------------------------------------------------

            await tx.paymentWebhookEvent.update({
              where: {
                eventId:
                  normalizedEventId,
              },
              data: {
                processed:
                  true,
                processedAt:
                  new Date(),
              },
            });

            return {
              alreadyProcessed:
                false,
            };
          }
        );

      if (
        result.alreadyProcessed
      ) {
        console.log(
          "RAZORPAY FAILED WEBHOOK ALREADY PROCESSED:",
          {
            eventId:
              normalizedEventId,
          }
        );

        return NextResponse.json(
          {
            success: true,
            duplicate: true,
            alreadyProcessed:
              true,
            message:
              "Webhook event already processed.",
          },
          {
            status: 200,
          }
        );
      }

      console.log(
        "RAZORPAY PAYMENT FAILED:",
        {
          eventId:
            normalizedEventId,
          razorpayOrderId,
          razorpayPaymentId,
          paymentId:
            payment.id,
          previousStatus:
            payment.status,
          courseId,
        }
      );

      return NextResponse.json(
        {
          success: true,
          message:
            "Payment failure recorded.",
        },
        {
          status: 200,
        }
      );
    }

    // ========================================================
    // 20. SAFETY FALLBACK
    // ========================================================

    return NextResponse.json(
      {
        success: true,
        message:
          "Webhook received.",
      },
      {
        status: 200,
      }
    );
  } catch (error) {
    // ========================================================
    // GLOBAL ERROR HANDLER
    //
    // IMPORTANT:
    // Do not mark webhook processed here.
    //
    // HTTP 500 allows Razorpay to retry.
    // ========================================================

    console.error(
      "RAZORPAY WEBHOOK ERROR:",
      error
    );

    return NextResponse.json(
      {
        success: false,
        message:
          "Unable to process webhook.",
      },
      {
        status: 500,
      }
    );
  }
}