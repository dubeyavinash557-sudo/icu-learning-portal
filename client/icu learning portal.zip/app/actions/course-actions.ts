"use server";

import prisma from "@/lib/prisma";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";

export async function createCourse(
  formData: FormData
) {
  const title = formData.get("title") as string;

  const slug = formData.get("slug") as string;

  const description =
    formData.get("description") as string;

  const price = Number(formData.get("price"));

  const isPremium =
    formData.get("isPremium") === "true";

      if (!title || !slug) {
    throw new Error("Title and slug are required.");
  }

  await prisma.course.create({
  data: {
    title,
    slug,
    description,

    image: (formData.get("image") as string) || "/images/default-course.jpg",

    instructor:
      (formData.get("instructor") as string) || "ICU Learning Team",

    price,

    duration: Number(formData.get("duration")) || 0,

    language:
      (formData.get("language") as string) || "Hindi",

    level:
      (formData.get("level") as string) || "Beginner",

    isPremium,
  },
});

      revalidatePath("/admin/courses");

  redirect("/admin/courses");
}

export async function updateCourse(
  formData: FormData
) {
  const id = formData.get("id") as string;

  const title = formData.get("title") as string;

  const slug = formData.get("slug") as string;

  const description =
    formData.get("description") as string;

  const image =
    (formData.get("image") as string) ||
    "/images/default-course.jpg";

  const instructor =
    (formData.get("instructor") as string) ||
    "ICU Learning Team";

  const price = Number(formData.get("price"));

  const duration = Number(
    formData.get("duration")
  );

  const language =
    (formData.get("language") as string) ||
    "Hindi";

  const level =
    (formData.get("level") as string) ||
    "Beginner";

  const isPremium =
    formData.get("isPremium") === "true";

      if (!id) {
    throw new Error("Course ID is missing.");
  }

  await prisma.course.update({
    where: {
      id,
    },
    data: {
      title,
      slug,
      description,
      image,
      instructor,
      price,
      duration,
      language,
      level,
      isPremium,
    },
  });

  revalidatePath("/admin/courses");

  revalidatePath(`/admin/courses/${id}`);

  revalidatePath(`/admin/courses/${id}/edit`);

    redirect(`/admin/courses/${id}`);
}

export async function toggleCoursePremium(
  id: string
) {
  "use server";

  const course = await prisma.course.findUnique({
    where: {
      id,
    },
  });

  if (!course) {
    throw new Error("Course not found.");
  }

  await prisma.course.update({
    where: {
      id,
    },
    data: {
      isPremium: !course.isPremium,
    },
  });

  revalidatePath("/admin/courses");

  revalidatePath(`/admin/courses/${id}`);

  revalidatePath(`/admin/courses/${id}/edit`);
}

export async function deleteCourse(
  id: string
) {
  "use server";

  const course = await prisma.course.findUnique({
    where: {
      id,
    },
  });

  if (!course) {
    throw new Error("Course not found.");
  }

  await prisma.course.delete({
    where: {
      id,
    },
  });

  revalidatePath("/admin/courses");

  redirect("/admin/courses");
}

export async function updateLesson(
  formData: FormData
) {
  const id = formData.get("id") as string;

  const courseId =
    formData.get("courseId") as string;

  const title = formData.get("title") as string;

  const description =
    formData.get("description") as string;

  const videoUrl =
    formData.get("videoUrl") as string;

  const notesUrl =
    (formData.get("notesUrl") as string) || null;

  const duration = Number(
    formData.get("duration")
  );

  const lessonOrder = Number(
    formData.get("lessonOrder")
  );

  if (!id || !courseId) {
    throw new Error("Missing required data.");
  }

  await prisma.lesson.update({
    where: {
      id,
    },
    data: {
      title,
      description,
      videoUrl,
      notesUrl,
      duration,
      lessonOrder,
    },
  });

  revalidatePath(
    `/admin/courses/${courseId}/lessons`
  );

  revalidatePath(
    `/admin/courses/${courseId}/lessons/${id}/edit`
  );

  redirect(
    `/admin/courses/${courseId}/lessons`
  );
}

export async function createLesson(
  formData: FormData
) {
  const courseId = formData.get("courseId") as string;

  const title = formData.get("title") as string;

  const description =
    formData.get("description") as string;

  const videoUrl = formData.get("videoUrl") as string;

  const notesUrl =
    (formData.get("notesUrl") as string) || null;

  const duration = Number(
    formData.get("duration")
  );

  const lessonOrder = Number(
    formData.get("lessonOrder")
  );

  if (!courseId || !title) {
    throw new Error("Course ID and Title are required.");
  }

  await prisma.lesson.create({
    data: {
      title,
      description,
      videoUrl,
      notesUrl,
      duration,
      lessonOrder,
      courseId,
    },
  });

  revalidatePath(
    `/admin/courses/${courseId}/lessons`
  );

  redirect(
    `/admin/courses/${courseId}/lessons`
  );
}

export async function createQuiz(
  formData: FormData
) {
  const title =
    formData.get("title") as string;

  const courseId =
    formData.get("courseId") as string;

  const description =
    (formData.get("description") as string) || null;

  if (!title || !courseId) {
    throw new Error(
      "Title and Course are required."
    );
  }

  await prisma.quiz.create({
    data: {
      title,
      description,
      courseId,
    },
  });

  revalidatePath("/admin/quizzes");

  redirect("/admin/quizzes");
}

export async function deleteLesson(
  lessonId: string,
  courseId: string
) {
  const lesson = await prisma.lesson.findUnique({
    where: {
      id: lessonId,
    },
  });

  if (!lesson) {
    throw new Error("Lesson not found.");
  }

  await prisma.lesson.delete({
    where: {
      id: lessonId,
    },
  });

  revalidatePath(
    `/admin/courses/${courseId}/lessons`
  );

  redirect(
    `/admin/courses/${courseId}/lessons`
  );
}

export async function deleteQuiz(
  quizId: string
) {
  const quiz = await prisma.quiz.findUnique({
    where: {
      id: quizId,
    },
  });

  if (!quiz) {
    throw new Error("Quiz not found.");
  }

  await prisma.quiz.delete({
    where: {
      id: quizId,
    },
  });

  revalidatePath("/admin/quizzes");

  redirect("/admin/quizzes");
}