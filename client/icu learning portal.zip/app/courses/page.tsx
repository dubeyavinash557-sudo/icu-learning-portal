import Link from "next/link";
import {
  ArrowRight,
  BookOpen,
  CheckCircle2,
  Clock3,
  Crown,
  GraduationCap,
  Languages,
  PlayCircle,
  Search,
  ShieldCheck,
  Sparkles,
  Star,
  Users,
  Video,
  FileText,
  Award,
  Zap,
} from "lucide-react";

import { getCourses } from "@/lib/course";

export default async function CoursesPage() {
  const courses = await getCourses();

  const totalCourses = courses.length;

  const totalLessons = courses.reduce(
    (total, course) => total + course.lessons.length,
    0
  );

  const premiumCourses = courses.filter(
    (course) => course.isPremium
  ).length;

  const freeCourses = totalCourses - premiumCourses;

  const totalStudents = courses.reduce(
    (total, course) => total + Number(course.students || 0),
    0
  );

  return (
    <main className="min-h-screen bg-slate-50 text-slate-900">

      {/* =====================================================
          HERO
      ===================================================== */}

      <section className="relative overflow-hidden bg-slate-950">
        {/* Background effects */}

        <div className="absolute inset-0">
          <div className="absolute -left-40 -top-40 h-[32rem] w-[32rem] rounded-full bg-cyan-500/20 blur-3xl" />

          <div className="absolute -right-40 top-20 h-[30rem] w-[30rem] rounded-full bg-blue-600/20 blur-3xl" />

          <div className="absolute bottom-[-12rem] left-1/2 h-[30rem] w-[30rem] -translate-x-1/2 rounded-full bg-indigo-600/10 blur-3xl" />
        </div>

        {/* Grid texture */}

        <div
          className="absolute inset-0 opacity-[0.08]"
          style={{
            backgroundImage:
              "linear-gradient(rgba(255,255,255,0.15) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.15) 1px, transparent 1px)",
            backgroundSize: "42px 42px",
          }}
        />

        <div className="relative mx-auto max-w-7xl px-5 py-16 sm:px-6 sm:py-20 lg:px-8 lg:py-24">

          <div className="grid items-center gap-12 lg:grid-cols-[1.2fr_0.8fr]">

            {/* LEFT */}

            <div>

              <div className="inline-flex items-center gap-2 rounded-full border border-cyan-400/30 bg-cyan-400/10 px-4 py-2 text-sm font-bold text-cyan-300 backdrop-blur">
                <Sparkles size={16} />
                Professional Critical Care Education
              </div>

              <h1 className="mt-7 max-w-4xl text-4xl font-black leading-[1.08] tracking-tight text-white sm:text-5xl lg:text-6xl">
                Master ICU & Critical Care
                <span className="block bg-gradient-to-r from-cyan-300 via-blue-300 to-indigo-300 bg-clip-text text-transparent">
                  With Structured Learning
                </span>
              </h1>

              <p className="mt-6 max-w-2xl text-base leading-8 text-slate-300 sm:text-lg">
                Build practical knowledge in ICU nursing, mechanical
                ventilation, ECG, ABG analysis, emergency care and
                other critical care subjects through structured
                lessons and professional learning resources.
              </p>

              {/* CTA */}

              <div className="mt-9 flex flex-col gap-3 sm:flex-row">

                <a
                  href="#course-list"
                  className="inline-flex items-center justify-center gap-2 rounded-2xl bg-cyan-500 px-7 py-4 text-sm font-black text-white shadow-xl shadow-cyan-500/20 transition hover:bg-cyan-400 hover:shadow-cyan-500/30"
                >
                  Explore Courses
                  <ArrowRight size={18} />
                </a>

                <Link
                  href="/dashboard"
                  className="inline-flex items-center justify-center gap-2 rounded-2xl border border-white/15 bg-white/10 px-7 py-4 text-sm font-black text-white backdrop-blur transition hover:bg-white/15"
                >
                  <PlayCircle size={18} />
                  Continue Learning
                </Link>

              </div>

              {/* Trust */}

              <div className="mt-9 flex flex-wrap gap-x-7 gap-y-3 text-sm text-slate-300">

                <div className="flex items-center gap-2">
                  <CheckCircle2
                    size={17}
                    className="text-emerald-400"
                  />
                  Structured Lessons
                </div>

                <div className="flex items-center gap-2">
                  <CheckCircle2
                    size={17}
                    className="text-emerald-400"
                  />
                  Progress Tracking
                </div>

                <div className="flex items-center gap-2">
                  <CheckCircle2
                    size={17}
                    className="text-emerald-400"
                  />
                  Certificates
                </div>

              </div>

            </div>

            {/* RIGHT - LMS STATS */}

            <div className="lg:justify-self-end lg:w-full lg:max-w-md">

              <div className="overflow-hidden rounded-[2rem] border border-white/10 bg-white/[0.07] p-5 shadow-2xl backdrop-blur-xl sm:p-7">

                <div className="rounded-2xl border border-white/10 bg-white/5 p-5">

                  <div className="flex items-center gap-4">

                    <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-cyan-500/15 text-cyan-300">
                      <GraduationCap size={28} />
                    </div>

                    <div>
                      <p className="text-xs font-bold uppercase tracking-wider text-cyan-300">
                        ICU Learning Portal
                      </p>

                      <h2 className="mt-1 text-xl font-black text-white">
                        Professional Learning Library
                      </h2>
                    </div>

                  </div>

                </div>

                {/* Stats */}

                <div className="mt-4 grid grid-cols-2 gap-3">

                  <HeroStat
                    value={String(totalCourses)}
                    label="Courses"
                    icon={<BookOpen size={18} />}
                  />

                  <HeroStat
                    value={String(totalLessons)}
                    label="Lessons"
                    icon={<Video size={18} />}
                  />

                  <HeroStat
                    value={String(premiumCourses)}
                    label="Premium"
                    icon={<Crown size={18} />}
                  />

                  <HeroStat
                    value={String(totalStudents)}
                    label="Learners"
                    icon={<Users size={18} />}
                  />

                </div>

                {/* Learning promise */}

                <div className="mt-4 rounded-2xl border border-emerald-400/10 bg-emerald-400/5 p-5">

                  <div className="flex items-start gap-3">

                    <div className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-emerald-400/10 text-emerald-400">
                      <ShieldCheck size={19} />
                    </div>

                    <div>
                      <p className="font-bold text-white">
                        Learn with a clear path
                      </p>

                      <p className="mt-1 text-sm leading-6 text-slate-400">
                        Structured courses, lessons, notes,
                        quizzes and progress tracking in one
                        learning platform.
                      </p>
                    </div>

                  </div>

                </div>

              </div>

            </div>

          </div>

        </div>
      </section>

      {/* =====================================================
          SEARCH / DISCOVERY BAR
      ===================================================== */}

      <section className="border-b border-slate-200 bg-white">

        <div className="mx-auto max-w-7xl px-5 py-5 sm:px-6 lg:px-8">

          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">

            <div>

              <p className="text-xs font-black uppercase tracking-[0.18em] text-cyan-600">
                Learning Library
              </p>

              <p className="mt-1 text-sm font-semibold text-slate-600">
                Find the right course for your ICU learning goals.
              </p>

            </div>

            <div className="flex w-full max-w-xl items-center gap-3 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 shadow-sm">

              <Search
                size={19}
                className="shrink-0 text-slate-400"
              />

              <span className="text-sm text-slate-400">
                Search ICU Nursing, Ventilator, ECG, ABG...
              </span>

            </div>

          </div>

        </div>

      </section>

      {/* =====================================================
          COURSE CATALOG
      ===================================================== */}

      <section
        id="course-list"
        className="mx-auto max-w-7xl px-5 py-16 sm:px-6 lg:px-8"
      >

        {/* Heading */}

        <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">

          <div className="max-w-3xl">

            <div className="inline-flex items-center gap-2 rounded-full bg-blue-50 px-4 py-2 text-sm font-black text-blue-700">
              <BookOpen size={16} />
              Our Learning Programs
            </div>

            <h2 className="mt-5 text-3xl font-black tracking-tight text-slate-950 sm:text-4xl lg:text-5xl">
              Choose Your Learning Path
            </h2>

            <p className="mt-4 text-base leading-7 text-slate-600 sm:text-lg">
              Explore professional courses designed to help you
              understand critical care concepts systematically and
              build practical ICU confidence.
            </p>

          </div>

          <div className="flex flex-wrap gap-3">

            <CatalogStat
              label="Programs"
              value={totalCourses}
            />

            <CatalogStat
              label="Free"
              value={freeCourses}
            />

            <CatalogStat
              label="Premium"
              value={premiumCourses}
            />

          </div>

        </div>

        {/* Courses */}

        {courses.length === 0 ? (
          <EmptyCourses />
        ) : (
          <div className="mt-12 grid gap-8 md:grid-cols-2 xl:grid-cols-3">
            {courses.map((course) => (
              <CourseCard
                key={course.id}
                course={course}
              />
            ))}
          </div>
        )}

      </section>

      {/* =====================================================
          PLATFORM BENEFITS
      ===================================================== */}

      <section className="border-y border-slate-200 bg-white">

        <div className="mx-auto max-w-7xl px-5 py-16 sm:px-6 lg:px-8">

          <div className="mx-auto max-w-3xl text-center">

            <div className="inline-flex items-center gap-2 rounded-full bg-cyan-50 px-4 py-2 text-sm font-black text-cyan-700">
              <Zap size={16} />
              Why Learn With Us
            </div>

            <h2 className="mt-5 text-3xl font-black text-slate-950 sm:text-4xl">
              More Than Just Video Courses
            </h2>

            <p className="mt-4 text-base leading-7 text-slate-600">
              The platform is being designed as a complete critical
              care learning ecosystem rather than a simple course
              website.
            </p>

          </div>

          <div className="mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-4">

            <BenefitCard
              icon={<Video size={23} />}
              title="Video Lessons"
              description="Structured lessons designed for focused and practical learning."
            />

            <BenefitCard
              icon={<FileText size={23} />}
              title="PDF Notes"
              description="Revision-friendly learning resources and downloadable study material."
            />

            <BenefitCard
              icon={<CheckCircle2 size={23} />}
              title="MCQs & Quizzes"
              description="Practice questions to test your knowledge and track improvement."
            />

            <BenefitCard
              icon={<Award size={23} />}
              title="Certificates"
              description="Complete eligible programs and work toward professional course certificates."
            />

          </div>

        </div>

      </section>

      {/* =====================================================
          PREMIUM CTA
      ===================================================== */}

      <section className="bg-slate-950">

        <div className="mx-auto max-w-7xl px-5 py-16 sm:px-6 lg:px-8">

          <div className="overflow-hidden rounded-[2rem] border border-white/10 bg-gradient-to-r from-blue-950 via-slate-900 to-cyan-950 p-7 shadow-2xl sm:p-10 lg:p-12">

            <div className="flex flex-col gap-8 lg:flex-row lg:items-center lg:justify-between">

              <div className="max-w-3xl">

                <div className="inline-flex items-center gap-2 rounded-full border border-amber-300/20 bg-amber-300/10 px-4 py-2 text-sm font-bold text-amber-300">
                  <Crown size={16} />
                  Premium Learning
                </div>

                <h2 className="mt-5 text-3xl font-black text-white sm:text-4xl">
                  Unlock a More Complete ICU Learning Experience
                </h2>

                <p className="mt-4 text-base leading-7 text-slate-300">
                  Premium learning will bring together advanced
                  lessons, structured notes, additional resources,
                  quizzes and other learning features in one place.
                </p>

                <div className="mt-6 flex flex-wrap gap-x-6 gap-y-3 text-sm font-semibold text-slate-300">

                  <span className="flex items-center gap-2">
                    <CheckCircle2
                      size={16}
                      className="text-emerald-400"
                    />
                    Advanced Lessons
                  </span>

                  <span className="flex items-center gap-2">
                    <CheckCircle2
                      size={16}
                      className="text-emerald-400"
                    />
                    Premium PDF Notes
                  </span>

                  <span className="flex items-center gap-2">
                    <CheckCircle2
                      size={16}
                      className="text-emerald-400"
                    />
                    Question Practice
                  </span>

                </div>

              </div>

              <Link
                href="/register"
                className="inline-flex shrink-0 items-center justify-center gap-2 rounded-2xl bg-white px-7 py-4 text-sm font-black text-slate-950 shadow-xl transition hover:bg-cyan-50"
              >
                Start Learning
                <ArrowRight size={18} />
              </Link>

            </div>

          </div>

        </div>

      </section>

    </main>
  );
}

/* ==========================================================
   COURSE CARD
========================================================== */

function CourseCard({
  course,
}: {
  course: Awaited<ReturnType<typeof getCourses>>[number];
}) {
  const price =
    typeof course.price === "number"
      ? course.price
      : Number(course.price);

  const formattedPrice =
    Number.isFinite(price) && price > 0
      ? `₹${price.toLocaleString("en-IN")}`
      : "Free";

  return (
    <article className="group flex h-full flex-col overflow-hidden rounded-[1.75rem] border border-slate-200 bg-white shadow-sm transition duration-300 hover:-translate-y-2 hover:border-blue-200 hover:shadow-2xl">

      {/* IMAGE */}

      <div className="relative h-60 overflow-hidden bg-slate-200">

        {course.image ? (
          <img
            src={course.image}
            alt={`${course.title} - ICU Learning Portal course`}
            className="h-full w-full object-cover transition duration-700 group-hover:scale-105"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-cyan-600 via-blue-700 to-indigo-800">
            <GraduationCap
              size={70}
              className="text-white/80"
            />
          </div>
        )}

        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/10 to-transparent" />

        {/* Premium */}

        <div className="absolute left-4 top-4">

          {course.isPremium ? (
            <span className="inline-flex items-center gap-1.5 rounded-full bg-amber-400 px-3.5 py-2 text-xs font-black text-amber-950 shadow-xl">
              <Crown size={14} />
              PREMIUM
            </span>
          ) : (
            <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-400 px-3.5 py-2 text-xs font-black text-emerald-950 shadow-xl">
              <CheckCircle2 size={14} />
              FREE
            </span>
          )}

        </div>

        {/* Level */}

        <div className="absolute bottom-4 left-4">

          <span className="rounded-full border border-white/20 bg-white/90 px-3 py-1.5 text-xs font-bold text-slate-800 shadow-lg backdrop-blur">
            {course.level}
          </span>

        </div>

        {/* Rating */}

        <div className="absolute bottom-4 right-4">

          <span className="inline-flex items-center gap-1 rounded-full bg-slate-950/75 px-3 py-1.5 text-xs font-bold text-white backdrop-blur">
            <Star
              size={13}
              className="fill-amber-400 text-amber-400"
            />

            {Number(course.rating).toFixed(1)}
          </span>

        </div>

      </div>

      {/* BODY */}

      <div className="flex flex-1 flex-col p-6">

        <div className="flex items-center justify-between gap-3">

          <span className="text-xs font-black uppercase tracking-wider text-blue-700">
            {course.instructor}
          </span>

          {course.isPremium && (
            <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-600">
              <Crown size={13} />
              Premium
            </span>
          )}

        </div>

        <h3 className="mt-3 line-clamp-2 min-h-[3.5rem] text-xl font-black leading-7 text-slate-900 transition group-hover:text-blue-700">
          {course.title}
        </h3>

        <p className="mt-3 line-clamp-3 text-sm leading-6 text-slate-600">
          {course.description}
        </p>

        {/* META */}

        <div className="mt-6 grid grid-cols-2 gap-2">

          <CourseMeta
            icon={<BookOpen size={15} />}
            value={`${course.lessons.length} Lessons`}
          />

          <CourseMeta
            icon={<Clock3 size={15} />}
            value={formatDuration(course.duration)}
          />

          <CourseMeta
            icon={<Languages size={15} />}
            value={course.language}
          />

          <CourseMeta
            icon={<Users size={15} />}
            value={`${Number(course.students).toLocaleString("en-IN")} Students`}
          />

        </div>

        {/* VALUE STRIP */}

        <div className="mt-5 rounded-2xl border border-blue-100 bg-blue-50/70 p-3">

          <div className="flex items-center gap-2 text-xs font-bold text-blue-800">

            <PlayCircle size={15} />

            Structured learning path included

          </div>

        </div>

        <div className="my-5 border-t border-slate-100" />

        {/* PRICE */}

        <div className="mt-auto">

          <div className="flex items-end justify-between gap-4">

            <div>

              <p className="text-[11px] font-black uppercase tracking-wider text-slate-400">
                Course Price
              </p>

              <p className="mt-1 text-2xl font-black text-blue-700">
                {formattedPrice}
              </p>

            </div>

            <div className="text-right">

              <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                Students
              </p>

              <p className="mt-1 text-sm font-black text-slate-700">
                {Number(course.students).toLocaleString("en-IN")}+
              </p>

            </div>

          </div>

          <Link
            href={`/courses/${course.id}`}
            className="mt-5 flex w-full items-center justify-center gap-2 rounded-2xl bg-blue-700 px-5 py-3.5 text-sm font-black text-white shadow-lg shadow-blue-700/20 transition hover:bg-blue-800 hover:shadow-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
          >
            View Course

            <ArrowRight
              size={17}
              className="transition-transform group-hover:translate-x-1"
            />
          </Link>

        </div>

      </div>

    </article>
  );
}

/* ==========================================================
   COURSE META
========================================================== */

function CourseMeta({
  icon,
  value,
}: {
  icon: React.ReactNode;
  value: string;
}) {
  return (
    <div className="flex min-w-0 items-center gap-2 rounded-xl bg-slate-50 px-3 py-2.5">

      <span className="shrink-0 text-blue-600">
        {icon}
      </span>

      <span className="truncate text-xs font-bold text-slate-600">
        {value}
      </span>

    </div>
  );
}

/* ==========================================================
   HERO STAT
========================================================== */

function HeroStat({
  value,
  label,
  icon,
}: {
  value: string;
  label: string;
  icon: React.ReactNode;
}) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-4">

      <div className="flex items-center justify-between">

        <p className="text-2xl font-black text-white">
          {value}
        </p>

        <span className="text-cyan-300">
          {icon}
        </span>

      </div>

      <p className="mt-1 text-xs font-bold text-slate-400">
        {label}
      </p>

    </div>
  );
}

/* ==========================================================
   CATALOG STAT
========================================================== */

function CatalogStat({
  label,
  value,
}: {
  label: string;
  value: number;
}) {
  return (
    <div className="min-w-[100px] rounded-2xl border border-slate-200 bg-white px-4 py-3 shadow-sm">

      <p className="text-[10px] font-black uppercase tracking-wider text-slate-400">
        {label}
      </p>

      <p className="mt-1 text-xl font-black text-slate-900">
        {value}
      </p>

    </div>
  );
}

/* ==========================================================
   BENEFIT CARD
========================================================== */

function BenefitCard({
  icon,
  title,
  description,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
}) {
  return (
    <div className="group rounded-3xl border border-slate-200 bg-slate-50 p-6 transition duration-300 hover:-translate-y-1 hover:border-blue-200 hover:bg-blue-50/50 hover:shadow-lg">

      <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-blue-100 text-blue-700 transition group-hover:bg-blue-700 group-hover:text-white">
        {icon}
      </div>

      <h3 className="mt-5 text-lg font-black text-slate-900">
        {title}
      </h3>

      <p className="mt-2 text-sm leading-6 text-slate-600">
        {description}
      </p>

    </div>
  );
}

/* ==========================================================
   EMPTY COURSES
========================================================== */

function EmptyCourses() {
  return (
    <div className="mt-12 overflow-hidden rounded-[2rem] border border-dashed border-slate-300 bg-white shadow-sm">

      <div className="mx-auto max-w-xl px-6 py-20 text-center sm:px-10">

        <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-3xl bg-blue-50 text-blue-700">
          <BookOpen size={38} />
        </div>

        <h2 className="mt-6 text-2xl font-black text-slate-900">
          Courses Coming Soon
        </h2>

        <p className="mt-3 text-base leading-7 text-slate-600">
          The learning library is currently being prepared.
          Professional ICU and critical care courses will appear
          here once they are added to the platform.
        </p>

        <div className="mt-7 inline-flex items-center gap-2 rounded-xl bg-slate-100 px-4 py-2.5 text-sm font-bold text-slate-600">
          <GraduationCap size={17} />
          ICU Learning Portal
        </div>

      </div>

    </div>
  );
}

/* ==========================================================
   DURATION FORMATTER
========================================================== */

function formatDuration(minutes: number) {
  if (
    !Number.isFinite(minutes) ||
    minutes <= 0
  ) {
    return "Self-paced";
  }

  const hours = Math.floor(minutes / 60);

  const remainingMinutes = minutes % 60;

  if (hours === 0) {
    return `${minutes} min`;
  }

  if (remainingMinutes === 0) {
    return `${hours} hr`;
  }

  return `${hours}h ${remainingMinutes}m`;
}